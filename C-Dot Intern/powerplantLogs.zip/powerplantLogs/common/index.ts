export const PLUGIN_ID = 'powerplantLogs';
export const PLUGIN_NAME = 'Powerplant Logs';

// ===== OpenSearch connection details =====
// Update these to match your environment, or override via env vars at request time
// (see server/routes/index.ts — OPENSEARCH_PASSWORD is read from process.env).
export const OPENSEARCH_HOST = process.env.OPENSEARCH_HOST || 'https://172.24.32.131:9200';
export const OPENSEARCH_USERNAME = process.env.OPENSEARCH_USERNAME || 'admin';
export const LOGS_INDEX = process.env.POWERPLANT_LOGS_INDEX || 'rtu-events';

// ===== Field taxonomy (used for simulation + dropdown seeding) =====
export const SEVERITY_LEVELS: string[] = ['INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

export const DEVICE_TYPES: string[] = [
  'SCADA',
  'RTU',
  'IED',
  'Firewall',
  'Switch',
  'Router',
  'Server',
  'Collector',
  'Data Diode',
  'NIDS',
];

export const PROTOCOLS: string[] = ['Modbus', 'DNP3', 'IEC104', 'IEC 61850', 'OPC UA', 'TCP', 'HTTP', 'SNMP', 'Syslog'];

export const EVENT_TYPES: string[] = [
  'Telemetry',
  'Alarm',
  'Authentication',
  'Network',
  'System',
  'Security',
  'Configuration',
  'Performance',
];

export const DEVICES: string[] = [
  'TURBINE-GEN-01',
  'TURBINE-GEN-02',
  'BOILER-UNIT-01',
  'BOILER-UNIT-02',
  'PLC-CTRL-01',
  'RTU-SUBSTATION-03',
  'HMI-CONTROL-ROOM',
  'SCADA-SERVER-PRIMARY',
  'SCADA-SERVER-BACKUP',
  'RELAY-PROTECTION-07',
  'TRANSFORMER-BANK-02',
  'FIREWALL-EDGE-GW',
  'COOLING-PUMP-04',
  'GENERATOR-EXCITER-01',
];

export const SIMULATED_DEVICE_COUNTS: Record<string, number> = {
  SCADA: 1,
  RTU: 5,
  IED: 15,
  Firewall: 2,
  Switch: 2,
  Router: 1,
  Server: 2,
  Collector: 1,
  'Data Diode': 0,
  NIDS: 1,
};

export const SIMULATED_EVENT_MESSAGES = [
  'Voltage Changed',
  'Temperature Increased',
  'Breaker Closed',
  'Breaker Open',
  'Firewall Login',
  'CPU High',
  'Device Offline',
  'Unauthorized Login',
  'Communication Failure',
  'Collector Started',
];
