import React, { useState, useEffect } from 'react';

export type TimeRange = '15m' | '1h' | '4h' | '24h' | '7d' | '30d' | 'custom';

interface HeaderBarProps {
  health: 'green' | 'yellow' | 'red';
  isLive: boolean;
  onToggleLive: () => void;
  dataSource: 'opensearch' | 'loading' | 'error';
  timeRange: TimeRange;
  onTimeRangeChange: (range: TimeRange) => void;
  customFrom: string;
  customTo: string;
  onCustomFromChange: (val: string) => void;
  onCustomToChange: (val: string) => void;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

const TIME_RANGES: { value: TimeRange; label: string }[] = [
  { value: '15m', label: '15 min' },
  { value: '1h', label: '1 hr' },
  { value: '4h', label: '4 hr' },
  { value: '24h', label: '24 hr' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: 'custom', label: 'Custom' },
];

export const HeaderBar: React.FC<HeaderBarProps> = ({
  health,
  isLive,
  onToggleLive,
  dataSource,
  timeRange,
  onTimeRangeChange,
  customFrom,
  customTo,
  onCustomFromChange,
  onCustomToChange,
  theme,
  onToggleTheme,
}) => {
  const [clock, setClock] = useState('');

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const date = now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
      const time = now.toLocaleTimeString('en-IN', { hour12: false });
      setClock(`${date}  ${time}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="plogs-header" style={{ flexWrap: 'wrap', gap: 10 }}>
      <div className="plogs-header-title">◈ Powerplant Logs</div>
      <div className="plogs-header-right" style={{ flexWrap: 'wrap' }}>
        {/* Time range filter */}
        <div className="plogs-time-filter">
          {TIME_RANGES.map((tr) => (
            <button
              key={tr.value}
              className={`plogs-time-btn ${timeRange === tr.value ? 'active' : ''}`}
              onClick={() => onTimeRangeChange(tr.value)}
            >
              {tr.label}
            </button>
          ))}
        </div>

        {/* Custom date range inputs */}
        {timeRange === 'custom' && (
          <div className="plogs-custom-range">
            <label style={{ color: '#9CA3AF', fontSize: 10, marginRight: 4 }}>FROM</label>
            <input
              type="datetime-local"
              className="plogs-datetime-input"
              value={customFrom}
              onChange={(e) => onCustomFromChange(e.target.value)}
            />
            <label style={{ color: '#9CA3AF', fontSize: 10, margin: '0 4px' }}>TO</label>
            <input
              type="datetime-local"
              className="plogs-datetime-input"
              value={customTo}
              onChange={(e) => onCustomToChange(e.target.value)}
            />
          </div>
        )}

        <div className="plogs-clock">{clock}</div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className={`plogs-status-dot ${health}`} />
          <span style={{ fontSize: 11, color: '#9CA3AF', textTransform: 'uppercase' as const, letterSpacing: 1 }}>
            {health === 'green' ? 'No Active Issues' : health === 'yellow' ? 'Warnings Present' : 'Critical Events'}
          </span>
        </div>

        {/* Data source indicator */}
        <div
          style={{
            fontSize: 11,
            color: dataSource === 'opensearch' ? '#00E5FF' : dataSource === 'error' ? '#EF4444' : '#9CA3AF',
            textTransform: 'uppercase',
            letterSpacing: 1,
            fontWeight: 600,
          }}
        >
          {dataSource === 'opensearch' ? '◉ OPENSEARCH' : dataSource === 'error' ? '⚠ OFFLINE' : '⟳ LOADING'}
        </div>

        <button className={`plogs-toggle-btn ${isLive ? 'active' : ''}`} onClick={onToggleLive}>
          {isLive ? '● AUTO-REFRESH' : '○ PAUSED'}
        </button>

        <button className="plogs-toggle-btn" onClick={onToggleTheme}>
          {theme === 'light' ? '☀ LIGHT' : '☾ DARK'}
        </button>
      </div>
    </div>
  );
};
