import React, { useRef, useEffect, useState } from 'react';

interface HistogramBucket {
  key: number | string;
  key_as_string?: string;
  by_severity: { buckets: { key: string; doc_count: number }[] };
}

interface LogHistogramProps {
  buckets: HistogramBucket[];
  onBucketRangeSelect: (fromISO: string, toISO: string) => void;
  theme: 'light' | 'dark';
}

const SEVERITY_ORDER = ['critical', 'error', 'warning', 'info', 'debug'];
const SEVERITY_COLORS: Record<string, string> = {
  critical: '#DC2626',
  error: '#EA580C',
  warning: '#EAB308',
  info: '#0284C7',
  debug: '#94A3B8',
};

function bucketKeyMs(b: HistogramBucket): number {
  return typeof b.key === 'number' ? b.key : new Date(b.key).getTime();
}

function bucketCounts(b: HistogramBucket): Record<string, number> {
  const out: Record<string, number> = {};
  for (const sb of b.by_severity?.buckets || []) out[sb.key.toLowerCase()] = sb.doc_count;
  return out;
}

function drawHistogram(canvas: HTMLCanvasElement, buckets: HistogramBucket[], hoverIdx: number | null) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const style = window.getComputedStyle(canvas);
  const getStyleVar = (name: string, fallback: string): string => {
    const val = style.getPropertyValue(name);
    return val && val.trim() ? val.trim() : fallback;
  };
  const textDim = getStyleVar('--plogs-text-dim', '#94A3B8');
  const textVal = getStyleVar('--plogs-text', '#1E293B');
  const borderVal = getStyleVar('--plogs-border', 'rgba(100, 116, 139, 0.15)');

  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);

  if (buckets.length === 0) {
    ctx.fillStyle = textDim;
    ctx.font = '12px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('No data in selected time range', w / 2, h / 2);
    return;
  }

  const pad = { top: 10, right: 10, bottom: 18, left: 36 };
  const cw = w - pad.left - pad.right;
  const ch = h - pad.top - pad.bottom;

  const totals = buckets.map((b) => {
    const c = bucketCounts(b);
    return SEVERITY_ORDER.reduce((sum, s) => sum + (c[s] || 0), 0);
  });
  const maxTotal = Math.max(1, ...totals);

  // grid lines
  ctx.strokeStyle = borderVal;
  ctx.lineWidth = 0.5;
  for (let i = 0; i <= 3; i++) {
    const y = pad.top + (ch / 3) * i;
    ctx.beginPath();
    ctx.moveTo(pad.left, y);
    ctx.lineTo(w - pad.right, y);
    ctx.stroke();
    const val = Math.round(maxTotal - (maxTotal / 3) * i);
    ctx.fillStyle = textDim;
    ctx.font = '9px JetBrains Mono, monospace';
    ctx.textAlign = 'right';
    ctx.fillText(String(val), pad.left - 5, y + 3);
  }

  const barGap = 2;
  const barWidth = Math.max(1, cw / buckets.length - barGap);

  buckets.forEach((b, i) => {
    const x = pad.left + i * (cw / buckets.length) + barGap / 2;
    const counts = bucketCounts(b);
    let yCursor = pad.top + ch;

    SEVERITY_ORDER.forEach((sev) => {
      const count = counts[sev] || 0;
      if (count <= 0) return;
      const barH = (count / maxTotal) * ch;
      yCursor -= barH;
      ctx.fillStyle = SEVERITY_COLORS[sev];
      ctx.globalAlpha = hoverIdx === null || hoverIdx === i ? 0.9 : 0.35;
      ctx.fillRect(x, yCursor, barWidth, barH);
    });
    ctx.globalAlpha = 1;

    if (hoverIdx === i) {
      ctx.strokeStyle = textVal;
      ctx.lineWidth = 1;
      ctx.strokeRect(x, pad.top, barWidth, ch);
    }
  });

  // x axis labels (first, middle, last)
  ctx.fillStyle = textDim;
  ctx.font = '9px JetBrains Mono, monospace';
  const fmt = (b: HistogramBucket) =>
    new Date(bucketKeyMs(b)).toLocaleString('en-IN', { hour12: false, month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  ctx.textAlign = 'left';
  ctx.fillText(fmt(buckets[0]), pad.left, h - 4);
  ctx.textAlign = 'right';
  ctx.fillText(fmt(buckets[buckets.length - 1]), w - pad.right, h - 4);
}

export const LogHistogram: React.FC<LogHistogramProps> = ({ buckets, onBucketRangeSelect, theme }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const [tooltip, setTooltip] = useState<{ x: number; y: number; lines: string[] } | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) drawHistogram(canvas, buckets, hoverIdx);
  }, [buckets, hoverIdx, theme]);

  const bucketIntervalMs = (): number => {
    if (buckets.length < 2) return 60000;
    return bucketKeyMs(buckets[1]) - bucketKeyMs(buckets[0]);
  };

  const idxFromX = (clientX: number): number | null => {
    const canvas = canvasRef.current;
    if (!canvas || buckets.length === 0) return null;
    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const pad = 36;
    const cw = rect.width - pad - 10;
    const idx = Math.floor(((x - pad) / cw) * buckets.length);
    if (idx < 0 || idx >= buckets.length) return null;
    return idx;
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const idx = idxFromX(e.clientX);
    setHoverIdx(idx);
    if (idx === null) {
      setTooltip(null);
      return;
    }
    const b = buckets[idx];
    const counts = bucketCounts(b);
    const total = SEVERITY_ORDER.reduce((s, sev) => s + (counts[sev] || 0), 0);
    const time = new Date(bucketKeyMs(b)).toLocaleString('en-IN', { hour12: false });
    const lines = [`${time}  —  ${total} events`];
    SEVERITY_ORDER.forEach((sev) => {
      if (counts[sev]) lines.push(`${sev}: ${counts[sev]}`);
    });
    const rect = canvasRef.current!.getBoundingClientRect();
    setTooltip({ x: e.clientX - rect.left + 10, y: e.clientY - rect.top - 10, lines });
  };

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const idx = idxFromX(e.clientX);
    if (idx === null) return;
    const interval = bucketIntervalMs();
    const fromMs = bucketKeyMs(buckets[idx]);
    const toMs = fromMs + interval;
    const toLocalInput = (ms: number) => {
      const d = new Date(ms);
      const pad = (n: number) => String(n).padStart(2, '0');
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    };
    onBucketRangeSelect(toLocalInput(fromMs), toLocalInput(toMs));
  };

  return (
    <div>
      <div className="plogs-section-title">Events Over Time</div>
      <div className="plogs-panel plogs-histogram-box" style={{ position: 'relative' }}>
        <canvas
          ref={canvasRef}
          className="plogs-histogram-canvas"
          onMouseMove={handleMouseMove}
          onMouseLeave={() => {
            setHoverIdx(null);
            setTooltip(null);
          }}
          onClick={handleClick}
        />
        {tooltip && (
          <div className="plogs-histogram-tooltip" style={{ left: tooltip.x, top: tooltip.y }}>
            {tooltip.lines.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </div>
        )}
        <div className="plogs-histogram-legend">
          {SEVERITY_ORDER.map((sev) => (
            <span key={sev} className="plogs-legend-item">
              <span className="plogs-legend-dot" style={{ background: SEVERITY_COLORS[sev] }} />
              {sev}
            </span>
          ))}
          <span style={{ color: '#4B5563', marginLeft: 'auto' }}>Click a bar to zoom into that interval</span>
        </div>
      </div>
    </div>
  );
};
