import React, { useState } from 'react';
import { LogEntry } from './app';

export type SortOrder = 'asc' | 'desc';

interface LogsTableProps {
  rows: LogEntry[];
  totalHits: number;
  page: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  sortOrder: SortOrder;
  onSortOrderChange: (order: SortOrder) => void;
  keyword: string;
  loading: boolean;
  exportRows: LogEntry[];
}

const SeverityColor = {
  critical: '#DC2626',
  high: '#EA580C',
  medium: '#EAB308',
  low: '#16A34A',
  warning: '#EAB308',
  info: '#0284C7',
  error: '#EA580C',
  debug: '#94A3B8',
} as const;

function severityColor(level: string): string {
  const key = level.toLowerCase() as keyof typeof SeverityColor;
  return SeverityColor[key] || '#9CA3AF';
}

function highlightKeyword(text: string, keyword: string): React.ReactNode {
  if (!keyword.trim()) return text;
  const q = keyword.trim();
  const lower = text.toLowerCase();
  const lowerQ = q.toLowerCase();
  const parts: React.ReactNode[] = [];
  let i = 0;
  let idx = lower.indexOf(lowerQ, i);
  if (idx === -1) return text;
  while (idx !== -1) {
    parts.push(text.slice(i, idx));
    parts.push(
      <mark key={idx} className="plogs-highlight">
        {text.slice(idx, idx + q.length)}
      </mark>
    );
    i = idx + q.length;
    idx = lower.indexOf(lowerQ, i);
  }
  parts.push(text.slice(i));
  return <>{parts}</>;
}

function exportCsv(rows: LogEntry[]) {
  const headers = 'Timestamp,Severity,Device,SourceIP,Protocol,EventType,Message\n';
  const escape = (v: string) => `"${String(v).replace(/"/g, '""')}"`;
  const body = rows
    .map((r) =>
      [r.timestamp, r.severity, r.device, r.sourceIp, r.protocol, r.eventType, r.message].map(escape).join(',')
    )
    .join('\n');
  const blob = new Blob([headers + body], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `powerplant_logs_${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export const LogsTable: React.FC<LogsTableProps> = ({
  rows,
  totalHits,
  page,
  pageSize,
  onPageChange,
  sortOrder,
  onSortOrderChange,
  keyword,
  loading,
  exportRows,
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const totalPages = Math.max(1, Math.ceil(totalHits / pageSize));
  const startIdx = page * pageSize;

  return (
    <div>
      <div className="plogs-section-title">Log Events</div>
      <div className="plogs-panel">
        <div className="plogs-table-toolbar">
          <span className="plogs-table-count">
            {loading ? 'Loading…' : `${totalHits.toLocaleString()} matching events`}
          </span>
          <button className="plogs-export-btn" onClick={() => exportCsv(exportRows)}>
            ⬇ Export CSV
          </button>
        </div>

        <div className="plogs-table-wrap">
          <table className="plogs-table">
            <thead>
              <tr>
                <th style={{ width: 24 }} />
                <th
                  className="plogs-sortable-th"
                  onClick={() => onSortOrderChange(sortOrder === 'desc' ? 'asc' : 'desc')}
                >
                  Timestamp {sortOrder === 'desc' ? '▼' : '▲'}
                </th>
                <th>Severity</th>
                <th>Device</th>
                <th>Source IP</th>
                <th>Protocol</th>
                <th>Message</th>
              </tr>
            </thead>
            <tbody>
              {!loading && rows.length === 0 && (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', color: '#4B5563', padding: 24 }}>
                    No log entries match the current filters
                  </td>
                </tr>
              )}
              {rows.map((row) => {
                const isOpen = expandedId === row.id;
                return (
                  <React.Fragment key={row.id}>
                    <tr
                      className={`plogs-row sev-${row.severity}`}
                      onClick={() => setExpandedId(isOpen ? null : row.id)}
                    >
                      <td className="plogs-expand-cell">{isOpen ? '▾' : '▸'}</td>
                      <td className="plogs-ts-cell">{row.timestamp}</td>
                      <td>
                        <span className="plogs-severity-badge" style={{ color: severityColor(row.severity) }}>
                          <span className="dot" style={{ background: severityColor(row.severity) }} />
                          {row.severity.toUpperCase()}
                        </span>
                      </td>
                      <td>{typeof row.device === 'object' ? JSON.stringify(row.device) : row.device}</td>
                      <td className="plogs-mono">{typeof row.sourceIp === 'object' ? JSON.stringify(row.sourceIp) : row.sourceIp || '—'}</td>
                      <td>{typeof row.protocol === 'object' ? JSON.stringify(row.protocol) : row.protocol}</td>
                      <td className="plogs-message-cell">{highlightKeyword(typeof row.message === 'object' ? JSON.stringify(row.message) : row.message, keyword)}</td>
                    </tr>
                    {isOpen && (
                      <tr className="plogs-detail-row">
                        <td colSpan={7}>
                          <div className="plogs-detail-grid">
                            <div>
                              <span className="plogs-detail-label">Event Type</span>
                              <span className="plogs-detail-value">{row.eventType}</span>
                            </div>
                            <div>
                              <span className="plogs-detail-label">Device</span>
                              <span className="plogs-detail-value">{row.device}</span>
                            </div>
                            <div>
                              <span className="plogs-detail-label">Source IP</span>
                              <span className="plogs-detail-value plogs-mono">{row.sourceIp || '—'}</span>
                            </div>
                            <div>
                              <span className="plogs-detail-label">Protocol</span>
                              <span className="plogs-detail-value">{row.protocol}</span>
                            </div>
                            <div style={{ gridColumn: '1 / -1' }}>
                              <span className="plogs-detail-label">Message</span>
                              <span className="plogs-detail-value">{row.message}</span>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="plogs-pagination">
          <span>
            {totalHits > 0 ? `${startIdx + 1}–${Math.min(startIdx + pageSize, totalHits)} of ${totalHits.toLocaleString()}` : '0 results'}
          </span>
          <button className="plogs-page-btn" disabled={page <= 0} onClick={() => onPageChange(page - 1)}>
            ◀ Prev
          </button>
          <span>
            Page {page + 1} / {totalPages}
          </span>
          <button className="plogs-page-btn" disabled={page >= totalPages - 1} onClick={() => onPageChange(page + 1)}>
            Next ▶
          </button>
        </div>
      </div>
    </div>
  );
};
