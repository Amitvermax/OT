import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { FieldOptions } from './app';

export interface LogFilters {
  severity: string[];
  device: string[];
  protocol: string[];
  eventType: string[];
}

interface SearchFilterBarProps {
  keyword: string;
  onKeywordChange: (val: string) => void;
  filters: LogFilters;
  onFiltersChange: (filters: LogFilters) => void;
  options: FieldOptions;
  totalHits: number;
}

const SEVERITY_COLORS: Record<string, string> = {
  critical: '#DC2626',
  high: '#EA580C',
  medium: '#EAB308',
  low: '#16A34A',
  warning: '#EAB308',
  info: '#0284C7',
  error: '#EA580C',
  debug: '#94A3B8',
};

function severityColor(level: string): string {
  return SEVERITY_COLORS[level.toLowerCase()] || '#9CA3AF';
}

// ===== Reusable multi-select filter dropdown =====
interface FilterDropdownProps {
  label: string;
  options: string[];
  selected: string[];
  onChange: (next: string[]) => void;
  swatchColor?: (opt: string) => string;
}

const FilterDropdown: React.FC<FilterDropdownProps> = ({ label, options, selected, onChange, swatchColor }) => {
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const panelRef = useRef<HTMLDivElement | null>(null);
  const [coords, setCoords] = useState<{ top: number; left: number; width: number } | null>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const target = e.target as Node;
      if (
        wrapperRef.current &&
        !wrapperRef.current.contains(target) &&
        panelRef.current &&
        !panelRef.current.contains(target)
      ) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const updateCoords = () => {
    const btn = buttonRef.current;
    if (!btn) return setCoords(null);
    const rect = btn.getBoundingClientRect();
    setCoords({ top: rect.bottom + window.scrollY, left: rect.left + window.scrollX, width: rect.width });
  };

  useEffect(() => {
    if (open) {
      updateCoords();
      window.addEventListener('resize', updateCoords);
      window.addEventListener('scroll', updateCoords, true);
      return () => {
        window.removeEventListener('resize', updateCoords);
        window.removeEventListener('scroll', updateCoords, true);
      };
    }
  }, [open]);

  const toggleValue = (val: string) => {
    if (selected.includes(val)) onChange(selected.filter((v) => v !== val));
    else onChange([...selected, val]);
  };

  const panel = open ? (
    <div
      ref={panelRef}
      className="plogs-filter-panel"
      style={{ position: 'fixed', top: coords ? coords.top : undefined, left: coords ? coords.left : undefined, minWidth: coords ? coords.width : 220 }}
    >
      <div className="plogs-filter-panel-header">
        <span>{label}</span>
        {selected.length > 0 && (
          <button className="plogs-filter-clear-link" onClick={() => onChange([])}>
            Clear
          </button>
        )}
      </div>
      <div className="plogs-filter-options">
        {options.length === 0 && <div className="plogs-filter-empty">No values available</div>}
        {options.map((opt) => (
          <label key={opt} className="plogs-filter-option">
            <input type="checkbox" checked={selected.includes(opt)} onChange={() => toggleValue(opt)} />
            {swatchColor && <span className="plogs-filter-swatch" style={{ background: swatchColor(opt) }} />}
            <span className="plogs-filter-option-label">{opt}</span>
          </label>
        ))}
      </div>
    </div>
  ) : null;

  return (
    <div className="plogs-filter-dropdown" ref={wrapperRef}>
      <button
        ref={buttonRef}
        className={`plogs-filter-btn ${selected.length > 0 ? 'active' : ''}`}
        onClick={() => setOpen((p) => !p)}
      >
        {label}
        {selected.length > 0 && <span className="plogs-filter-count">{selected.length}</span>}
        <span className="plogs-filter-caret">▾</span>
      </button>
      {panel && createPortal(panel, document.body)}
    </div>
  );
};

export const SearchFilterBar: React.FC<SearchFilterBarProps> = ({
  keyword,
  onKeywordChange,
  filters,
  onFiltersChange,
  options,
  totalHits,
}) => {
  const [localKeyword, setLocalKeyword] = useState(keyword);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => setLocalKeyword(keyword), [keyword]);

  const handleKeywordInput = (val: string) => {
    setLocalKeyword(val);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => onKeywordChange(val), 350);
  };

  const activeFilterCount =
    filters.severity.length + filters.device.length + filters.protocol.length + filters.eventType.length;

  const clearAll = useCallback(() => {
    onFiltersChange({ severity: [], device: [], protocol: [], eventType: [] });
    setLocalKeyword('');
    onKeywordChange('');
  }, [onFiltersChange, onKeywordChange]);

  return (
    <div>
      <div className="plogs-panel plogs-search-toolbar">
        <div className="plogs-search-row">
          <span className="plogs-search-icon">⌕</span>
          <input
            className="plogs-search-input"
            placeholder="Search messages, devices, IPs, protocols…"
            value={localKeyword}
            onChange={(e) => handleKeywordInput(e.target.value)}
          />
          {localKeyword && (
            <button className="plogs-search-clear" onClick={() => handleKeywordInput('')}>
              ✕
            </button>
          )}
        </div>

        <div className="plogs-filter-row">
          <FilterDropdown
            label="Severity"
            options={options.severity}
            selected={filters.severity}
            onChange={(next) => onFiltersChange({ ...filters, severity: next })}
            swatchColor={severityColor}
          />
          <FilterDropdown
            label="Device"
            options={options.device}
            selected={filters.device}
            onChange={(next) => onFiltersChange({ ...filters, device: next })}
          />
          <FilterDropdown
            label="Protocol"
            options={options.protocol}
            selected={filters.protocol}
            onChange={(next) => onFiltersChange({ ...filters, protocol: next })}
          />
          <FilterDropdown
            label="Event Type"
            options={options.eventType}
            selected={filters.eventType}
            onChange={(next) => onFiltersChange({ ...filters, eventType: next })}
          />

          {activeFilterCount > 0 && (
            <button className="plogs-clear-all-btn" onClick={clearAll}>
              Clear all filters
            </button>
          )}

          <div className="plogs-hit-count">{totalHits.toLocaleString()} hits</div>
        </div>
      </div>
    </div>
  );
};
