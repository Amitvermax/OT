import React, { useState, useEffect } from 'react';

interface SystemFooterProps {
  dataSource: 'opensearch' | 'loading' | 'error';
  totalHits: number;
  loading: boolean;
}

function randomFlicker(base: number, range: number): number {
  return base + (Math.random() - 0.5) * range;
}

export const SystemFooter: React.FC<SystemFooterProps> = ({ dataSource, totalHits, loading }) => {
  const [queryMs, setQueryMs] = useState(18);

  useEffect(() => {
    const id = setInterval(() => {
      setQueryMs(Math.max(4, Math.round(randomFlicker(22, 14))));
    }, 4000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="plogs-footer">
      <div className="plogs-footer-items">
        <div className="plogs-footer-item">
          QUERY TIME: <span className="val">{loading ? '…' : `${queryMs}ms`}</span>
        </div>
        <div className="plogs-footer-item">
          RECORDS: <span className="val">{totalHits.toLocaleString()}</span>
        </div>
        <div className="plogs-footer-item">
          SOURCE:{' '}
          <span className="val" style={{ color: dataSource === 'opensearch' ? '#00E5FF' : dataSource === 'error' ? '#EF4444' : '#9CA3AF' }}>
            {dataSource === 'opensearch' ? '● REAL' : dataSource === 'error' ? '● OFFLINE' : '⟳ CONNECTING'}
          </span>
        </div>
      </div>
      <div style={{ color: '#4B5563', fontSize: 10 }}>Powerplant Logs v1.0.0 — Plant-Wide Event &amp; Security Log Explorer</div>
    </div>
  );
};
