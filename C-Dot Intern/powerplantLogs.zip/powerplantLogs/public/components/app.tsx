import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { HeaderBar, TimeRange } from './HeaderBar';
import { SearchFilterBar, LogFilters } from './SearchFilterBar';
import { LogHistogram } from './LogHistogram';
import { LogsTable, SortOrder } from './LogsTable';
import { SystemFooter } from './SystemFooter';
import { DEVICE_TYPES, PROTOCOLS, EVENT_TYPES, SEVERITY_LEVELS } from '../../common';

// ===== TYPES =====
export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info' | 'error' | 'warning' | 'debug';

export interface LogEntry {
  id: string;
  timestamp: string;
  severity: Severity;
  device: string;
  sourceIp: string;
  protocol: string;
  eventType: string;
  message: string;
}

export interface FieldOptions {
  severity: string[];
  device: string[];
  protocol: string[];
  eventType: string[];
}

const PAGE_SIZE = 25;
const REFRESH_INTERVAL_MS = 10000;

const EMPTY_FILTERS: LogFilters = { severity: [], device: [], protocol: [], eventType: [] };

// ===== MAP OPENSEARCH DOCUMENT → LogEntry =====
function toDisplayValue(value: any, fallback = ''): string {
  if (value === undefined || value === null) {
    return fallback;
  }

  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
    return String(value);
  }

  if (typeof value === 'object') {
    if (typeof value.name === 'string' && value.name.trim()) {
      return value.name;
    }
    if (typeof value.ip === 'string' && value.ip.trim()) {
      return value.ip;
    }
    if (typeof value.id === 'string' && value.id.trim()) {
      return value.id;
    }
    if (typeof value.site === 'string' && value.site.trim()) {
      return String(value.site);
    }
    if (typeof value.message === 'string' && value.message.trim()) {
      return value.message;
    }
    return JSON.stringify(value);
  }

  return fallback;
}

function mapToLogEntry(source: any, fallbackId: string): LogEntry {
  const rawDevice = source.device || source.device_name || source.host || 'unknown';
  const rawDeviceType = typeof rawDevice === 'object' ? rawDevice.type || rawDevice.name || rawDevice.ip || 'unknown' : rawDevice;
  const rawSourceIp = source.source_ip || source.src_ip || source.ip || (typeof source.device === 'object' ? source.device.ip : '') || '';

  return {
    id: toDisplayValue(source.id || source._id || fallbackId, fallbackId),
    timestamp: toDisplayValue(source.timestamp || source['@timestamp'] || ''),
    severity: toDisplayValue(source.severity || source.log_level || source.event?.severity || 'info').toLowerCase() as Severity,
    device: toDisplayValue(rawDeviceType, 'unknown'),
    sourceIp: toDisplayValue(rawSourceIp, ''),
    protocol: toDisplayValue(source.protocol || source.proto || source.event?.protocol || 'TCP', 'TCP'),
    eventType: toDisplayValue(source.event_type || source.category || source.event?.type || 'General', 'General'),
    message: toDisplayValue(source.message || source.event?.message || source.event_message || source.msg || ''),
  };
}

// ===== TIME RANGE → ISO TIMESTAMP =====

function timeRangeToISO(range: TimeRange, customFrom: string, customTo: string): { gte: string; lte?: string } {
  if (range === 'custom') {
    return {
      gte: customFrom ? new Date(customFrom).toISOString() : new Date(Date.now() - 60 * 60000).toISOString(),
      lte: customTo ? new Date(customTo).toISOString() : new Date().toISOString(),
    };
  }
  const mins: Record<string, number> = {
    '15m': 15,
    '1h': 60,
    '4h': 240,
    '24h': 1440,
    '7d': 10080,
    '30d': 43200,
  };
  const ms = (mins[range] || 60) * 60000;
  return { gte: new Date(Date.now() - ms).toISOString() };
}

function timeRangeToMs(range: TimeRange, customFrom: string, customTo: string): number {
  if (range === 'custom') {
    const from = customFrom ? new Date(customFrom).getTime() : Date.now() - 3600000;
    const to = customTo ? new Date(customTo).getTime() : Date.now();
    return Math.max(60000, to - from);
  }
  const mins: Record<string, number> = { '15m': 15, '1h': 60, '4h': 240, '24h': 1440, '7d': 10080, '30d': 43200 };
  return (mins[range] || 60) * 60000;
}



// ===== MAIN COMPONENT =====
export const LogsDashboard: React.FC<{ http: any; notifications: any }> = ({ http, notifications }) => {
  const [rows, setRows] = useState<LogEntry[]>([]);
  const [totalHits, setTotalHits] = useState(0);
  const [loading, setLoading] = useState(true);
  const [dataSource, setDataSource] = useState<'opensearch' | 'loading' | 'error'>('loading');
  const [isLive, setIsLive] = useState(true);
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      return (localStorage.getItem('plogs-theme') as 'light' | 'dark') || 'light';
    } catch {
      return 'light';
    }
  });

  const toggleTheme = useCallback(() => {
    setTheme((prev) => {
      const next = prev === 'light' ? 'dark' : 'light';
      try {
        localStorage.setItem('plogs-theme', next);
      } catch (e) {
        // ignore
      }
      return next;
    });
  }, []);

  const [timeRange, setTimeRange] = useState<TimeRange>('1h');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');

  const [filters, setFilters] = useState<LogFilters>(EMPTY_FILTERS);
  const [keyword, setKeyword] = useState('');
  const [page, setPage] = useState(0);
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const [histogramBuckets, setHistogramBuckets] = useState<any[]>([]);
  const [fieldOptions, setFieldOptions] = useState<FieldOptions>({
    severity: [...SEVERITY_LEVELS],
    device: DEVICE_TYPES,
    protocol: PROTOCOLS,
    eventType: EVENT_TYPES,
  });



  // ── Fetch a page of logs from OpenSearch ──
  const fetchLogs = useCallback(async () => {
    const timeFilter = timeRangeToISO(timeRange, customFrom, customTo);
    const body = {
      size: PAGE_SIZE,
      from: page * PAGE_SIZE,
      sort_order: sortOrder,
      time_gte: timeFilter.gte,
      time_lte: timeFilter.lte,
      severity: filters.severity,
      device: filters.device,
      protocol: filters.protocol,
      event_type: filters.eventType,
      keyword: keyword || undefined,
    };
    try {
      const result = await http.post('/api/powerplant_logs/data', { body: JSON.stringify(body) });
      const hits = result?.hits?.hits || [];
      const total = result?.hits?.total?.value ?? result?.hits?.total ?? hits.length;

      setDataSource('opensearch');
      setRows(hits.map((h: any, i: number) => mapToLogEntry(h._source, h._id || `os-${i}`)));
      setTotalHits(total);
      return true;
    } catch (err: unknown) {
      console.error('OpenSearch log fetch failed:', err);
      const errorMessage = err instanceof Error ? err.message : typeof err === 'string' ? err : 'Unable to fetch data from the server';
      notifications.toasts.addDanger({
        title: 'Powerplant Logs: OpenSearch request failed',
        text: errorMessage,
      });
      setDataSource('error');
      setRows([]);
      setTotalHits(0);
      return false;
    }
  }, [http, page, sortOrder, timeRange, customFrom, customTo, filters, keyword]);

  // ── Fetch histogram from OpenSearch ──
  const fetchHistogram = useCallback(async () => {
    const timeFilter = timeRangeToISO(timeRange, customFrom, customTo);
    const rangeMs = timeRangeToMs(timeRange, customFrom, customTo);
    const interval = rangeMs > 7 * 86400000 ? '1d' : rangeMs > 86400000 ? '1h' : rangeMs > 3 * 3600000 ? '5m' : '1m';
    const body = {
      time_gte: timeFilter.gte,
      time_lte: timeFilter.lte,
      interval,
      severity: filters.severity,
      device: filters.device,
      protocol: filters.protocol,
      event_type: filters.eventType,
      keyword: keyword || undefined,
    };
    try {
      const result = await http.post('/api/powerplant_logs/histogram', { body: JSON.stringify(body) });
      setHistogramBuckets(result?.aggregations?.over_time?.buckets || []);
    } catch (err) {
      // silent — histogram is supplementary
    }
  }, [http, timeRange, customFrom, customTo, filters, keyword]);

  // ── Fetch distinct field values for filter dropdowns ──
  const fetchFieldValues = useCallback(async () => {
    try {
      const result = await http.get('/api/powerplant_logs/field_values');
      const agg = result?.aggregations;
      if (!agg) return;
      
      // Helper to safely extract keys from aggregation buckets
      const extractKeys = (buckets: any[] | undefined): string[] => {
        if (!Array.isArray(buckets)) return [];
        return buckets
          .map((b: any) => (typeof b?.key === 'string' ? b.key : null))
          .filter((key): key is string => key !== null);
      };

      const unique = (items: string[]) => Array.from(new Set(items));
      const extractedSeverity = extractKeys(agg.severities?.buckets).map((v) => v.toUpperCase());
      const extractedDeviceTypes = extractKeys(agg.device_types?.buckets).map((v) => v.toUpperCase());
      const extractedProtocols = extractKeys(agg.protocols?.buckets);
      const extractedEventTypes = extractKeys(agg.event_types?.buckets).length
        ? extractKeys(agg.event_types?.buckets)
        : extractKeys(agg.event_types_nested?.buckets);

      setFieldOptions({
        severity: unique([...SEVERITY_LEVELS, ...extractedSeverity]),
        device: unique([...DEVICE_TYPES, ...extractedDeviceTypes]),
        protocol: unique([...PROTOCOLS, ...extractedProtocols]),
        eventType: unique([...EVENT_TYPES, ...extractedEventTypes]),
      });
    } catch (err) {
      // keep defaults
    }
  }, [http]);



  // ── Reset to page 0 whenever filters/keyword/range/sort change ──
  useEffect(() => {
    setPage(0);
  }, [timeRange, customFrom, customTo, filters, keyword, sortOrder]);

  // ── Main load + refresh loop ──
  useEffect(() => {
    let cancelled = false;
    setLoading(true);

    const load = async () => {
      const ok = await fetchLogs();
      if (cancelled) return;
      if (ok) {
        await fetchHistogram();
        await fetchFieldValues();
      }
      setLoading(false);
    };

    load();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, sortOrder, timeRange, customFrom, customTo, filters, keyword]);

  // ── Auto-refresh on live tick ──
  useEffect(() => {
    if (!isLive) return;
    const id = setInterval(() => {
      fetchLogs();
      fetchHistogram();
    }, REFRESH_INTERVAL_MS);
    return () => clearInterval(id);
  }, [isLive, fetchLogs, fetchHistogram]);

  const criticalCount = useMemo(() => rows.filter((r) => r.severity === 'critical').length, [rows]);
  const systemHealth: 'green' | 'yellow' | 'red' =
    criticalCount > 0 ? 'red' : rows.some((r) => r.severity === 'error' || r.severity === 'warning') ? 'yellow' : 'green';

  const exportRows = rows;

  return (
    <div className={`plogs-root theme-${theme}`}>
      <HeaderBar
        health={systemHealth}
        isLive={isLive}
        onToggleLive={() => setIsLive((p) => !p)}
        dataSource={dataSource}
        timeRange={timeRange}
        onTimeRangeChange={setTimeRange}
        customFrom={customFrom}
        customTo={customTo}
        onCustomFromChange={setCustomFrom}
        onCustomToChange={setCustomTo}
        theme={theme}
        onToggleTheme={toggleTheme}
      />
      <div className="plogs-main">
        <SearchFilterBar
          keyword={keyword}
          onKeywordChange={setKeyword}
          filters={filters}
          onFiltersChange={setFilters}
          options={fieldOptions}
          totalHits={totalHits}
        />

        <LogHistogram
          buckets={histogramBuckets}
          onBucketRangeSelect={(from, to) => {
            setCustomFrom(from);
            setCustomTo(to);
            setTimeRange('custom');
          }}
          theme={theme}
        />

        <LogsTable
          rows={rows}
          totalHits={totalHits}
          page={page}
          pageSize={PAGE_SIZE}
          onPageChange={setPage}
          sortOrder={sortOrder}
          onSortOrderChange={setSortOrder}
          keyword={keyword}
          loading={loading}
          exportRows={exportRows}
        />

        <SystemFooter dataSource={dataSource} totalHits={totalHits} loading={loading} />
      </div>
    </div>
  );
};
