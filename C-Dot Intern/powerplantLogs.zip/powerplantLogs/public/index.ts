import './index.scss';

import { PowerplantLogsPlugin } from './plugin';

export function plugin() {
  return new PowerplantLogsPlugin();
}
export { PowerplantLogsPluginSetup, PowerplantLogsPluginStart } from './types';
