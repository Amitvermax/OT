import { i18n } from '@osd/i18n';
import { AppMountParameters, CoreSetup, CoreStart, Plugin } from '../../../../src/core/public';
import {
  PowerplantLogsPluginSetup,
  PowerplantLogsPluginStart,
  AppPluginStartDependencies,
} from './types';
import { PLUGIN_NAME } from '../common';

export class PowerplantLogsPlugin
  implements Plugin<PowerplantLogsPluginSetup, PowerplantLogsPluginStart> {
  public setup(core: CoreSetup): PowerplantLogsPluginSetup {
    core.application.register({
      id: 'powerplantLogs',
      title: PLUGIN_NAME,
      order: 8,
      category: {
        id: 'powerplant',
        label: 'Powerplant',
        order: 0,
      },
      async mount(params: AppMountParameters) {
        const { renderApp } = await import('./application');
        const [coreStart, depsStart] = await core.getStartServices();
        return renderApp(coreStart, depsStart as AppPluginStartDependencies, params);
      },
    });

    return {
      getGreeting() {
        return i18n.translate('powerplantLogs.greetingText', {
          defaultMessage: 'Hello from {name}!',
          values: {
            name: PLUGIN_NAME,
          },
        });
      },
    };
  }

  public start(core: CoreStart): PowerplantLogsPluginStart {
    return {};
  }

  public stop() {}
}
