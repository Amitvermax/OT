import { PluginInitializerContext } from '../../../src/core/server';
import { PowerplantLogsPlugin } from './plugin';

export function plugin(initializerContext: PluginInitializerContext) {
  return new PowerplantLogsPlugin(initializerContext);
}

export { PowerplantLogsPluginSetup, PowerplantLogsPluginStart } from './types';
