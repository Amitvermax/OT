import {
  PluginInitializerContext,
  CoreSetup,
  CoreStart,
  Plugin,
  Logger,
} from '../../../src/core/server';

import { PowerplantLogsPluginSetup, PowerplantLogsPluginStart } from './types';
import { defineRoutes } from './routes';

export class PowerplantLogsPlugin
  implements Plugin<PowerplantLogsPluginSetup, PowerplantLogsPluginStart> {
  private readonly logger: Logger;

  constructor(initializerContext: PluginInitializerContext) {
    this.logger = initializerContext.logger.get();
  }

  public setup(core: CoreSetup) {
    this.logger.debug('powerplantLogs: Setup');
    const router = core.http.createRouter();
    defineRoutes(router);
    return {};
  }

  public start(core: CoreStart) {
    this.logger.debug('powerplantLogs: Started');
    return {};
  }

  public stop() {}
}
