import { schema } from '@osd/config-schema';
import http from 'http';
import https from 'https';
import { OPENSEARCH_HOST, OPENSEARCH_USERNAME, LOGS_INDEX } from '../../common';

// Equivalent of Python's verify=False — skip TLS verification for self-signed certs
const insecureHttpsAgent = new https.Agent({ rejectUnauthorized: false });

function getCredentials(): string {
  const password = process.env.OPENSEARCH_PASSWORD || 'cdot@siem@123';
  return Buffer.from(`${OPENSEARCH_USERNAME}:${password}`).toString('base64');
}

function queryOpenSearch(path: string, method: 'GET' | 'POST', body: any, credentials: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const url = new URL(path, OPENSEARCH_HOST);
    const postData = body ? JSON.stringify(body) : undefined;
    const useHttps = url.protocol === 'https:';

    const req = (useHttps ? https : http).request(
      {
        hostname: url.hostname,
        port: url.port || (useHttps ? 9200 : 9200),
        path: url.pathname,
        method,
        agent: useHttps ? insecureHttpsAgent : undefined,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Basic ${credentials}`,
          ...(postData ? { 'Content-Length': Buffer.byteLength(postData) } : {}),
        },
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(new Error(`Failed to parse OpenSearch response: ${data.substring(0, 200)}`));
          }
        });
      }
    );

    req.on('error', (err) => reject(err));
    if (postData) req.write(postData);
    req.end();
  });
}

// ── Build a bool query shared by /data and /histogram ──
function buildTermsFilter(fields: string[], values: string[]) {
  if (!values || values.length === 0) return null;

  const normalizedValues = Array.from(
    new Set(
      values.flatMap((value) => [value, String(value).toLowerCase(), String(value).toUpperCase()])
    )
  );

  if (fields.length === 1) return { terms: { [fields[0]]: normalizedValues } };

  return {
    bool: {
      should: fields.map((field) => ({ terms: { [field]: normalizedValues } })),
      minimum_should_match: 1,
    },
  };
}

function buildLogsQuery(params: {
  time_gte?: string;
  time_lte?: string;
  from_timestamp?: string;
  severity?: string[];
  device?: string[];
  protocol?: string[];
  event_type?: string[];
  keyword?: string;
}) {
  const filters: any[] = [];

  if (params.time_gte || params.time_lte) {
    const rangeFilter: any = {};
    if (params.time_gte) rangeFilter.gte = params.time_gte;
    if (params.time_lte) rangeFilter.lte = params.time_lte;
    filters.push({ range: { '@timestamp': rangeFilter } });
  }

  if (params.from_timestamp) {
    filters.push({ range: { '@timestamp': { gt: params.from_timestamp } } });
  }

  if (params.severity && params.severity.length > 0) {
    filters.push(
      buildTermsFilter(['severity', 'event.severity', 'event.severity.keyword'], params.severity)
    );
  }
  if (params.device && params.device.length > 0) {
    filters.push(
      buildTermsFilter(['device', 'device.type', 'device.name', 'device.id', 'host'], params.device)
    );
  }
  if (params.protocol && params.protocol.length > 0) {
    filters.push(
      buildTermsFilter(['protocol', 'event.protocol'], params.protocol)
    );
  }
  if (params.event_type && params.event_type.length > 0) {
    filters.push(
      buildTermsFilter(['event_type', 'event.type', 'category'], params.event_type)
    );
  }

  if (params.keyword && params.keyword.trim()) {
    filters.push({
      multi_match: {
        query: params.keyword.trim(),
        fields: [
          'message^3',
          'event.message^3',
          'device^2',
          'device.name^2',
          'device.type',
          'host',
          'source_ip',
          'src_ip',
          'protocol',
          'event.protocol',
          'event_type',
          'event.type',
          'category',
        ],
        fuzziness: 'AUTO',
      },
    });
  }

  const cleanedFilters = filters.filter(Boolean);
  return cleanedFilters.length > 0 ? { bool: { must: cleanedFilters } } : { match_all: {} };
}

export function defineRoutes(router) {
  // ── Search logs with filters / time range / keyword / pagination ──
  router.post(
    {
      path: '/api/powerplant_logs/data',
      validate: {
        body: schema.object({
          size: schema.number({ defaultValue: 50 }),
          from: schema.number({ defaultValue: 0 }),
          sort_order: schema.oneOf([schema.literal('asc'), schema.literal('desc')], { defaultValue: 'desc' }),
          from_timestamp: schema.maybe(schema.string()),
          time_gte: schema.maybe(schema.string()),
          time_lte: schema.maybe(schema.string()),
          severity: schema.arrayOf(schema.string(), { defaultValue: [] }),
          device: schema.arrayOf(schema.string(), { defaultValue: [] }),
          protocol: schema.arrayOf(schema.string(), { defaultValue: [] }),
          event_type: schema.arrayOf(schema.string(), { defaultValue: [] }),
          keyword: schema.maybe(schema.string()),
        }),
      },
    },
    async (context, request, response) => {
      try {
        const { size, from, sort_order, ...filterParams } = request.body;
        const query = buildLogsQuery(filterParams);

        const searchBody = {
          query,
          sort: [{ "@timestamp": { order: sort_order } }],
          from,
          size,
          track_total_hits: true,
        };

        const credentials = getCredentials();
        const result = await queryOpenSearch(`/${LOGS_INDEX}/_search`, 'POST', searchBody, credentials);

        if (result.error) {
          console.error('OpenSearch query error:', JSON.stringify(result.error));
          return response.customError({
            statusCode: result.status || 500,
            body: { message: result.error?.reason || 'OpenSearch query failed' },
          });
        }

        return response.ok({ body: result });
      } catch (error) {
        console.error('Powerplant logs data fetch error:', error.message || error);
        return response.customError({
          statusCode: 500,
          body: { message: error.message || 'Failed to query OpenSearch for log data' },
        });
      }
    }
  );

  // ── Date histogram bucketed by severity (for the Discover-style bar chart) ──
  router.post(
    {
      path: '/api/powerplant_logs/histogram',
      validate: {
        body: schema.object({
          time_gte: schema.maybe(schema.string()),
          time_lte: schema.maybe(schema.string()),
          interval: schema.string({ defaultValue: 'auto' }),
          severity: schema.arrayOf(schema.string(), { defaultValue: [] }),
          device: schema.arrayOf(schema.string(), { defaultValue: [] }),
          protocol: schema.arrayOf(schema.string(), { defaultValue: [] }),
          event_type: schema.arrayOf(schema.string(), { defaultValue: [] }),
          keyword: schema.maybe(schema.string()),
        }),
      },
    },
    async (context, request, response) => {
      try {
        const { interval, ...filterParams } = request.body;
        const query = buildLogsQuery(filterParams);

        const searchBody = {
          query,
          size: 0,
          aggs: {
            over_time: {
              date_histogram: {
                field: '@timestamp',
                fixed_interval: interval === 'auto' ? '1m' : interval,
                min_doc_count: 0,
              },
              aggs: {
                by_severity: { terms: { field: 'event.severity', size: 10 } },
              },
            },
          },
        };

        const credentials = getCredentials();
        const result = await queryOpenSearch(`/${LOGS_INDEX}/_search`, 'POST', searchBody, credentials);

        if (result.error) {
          return response.customError({
            statusCode: result.status || 500,
            body: { message: result.error?.reason || 'OpenSearch histogram query failed' },
          });
        }

        return response.ok({ body: result });
      } catch (error) {
        console.error('Powerplant logs histogram error:', error.message || error);
        return response.customError({
          statusCode: 500,
          body: { message: error.message || 'Failed to query histogram' },
        });
      }
    }
  );

  // ── Distinct field values for filter dropdowns (terms aggregation) ──
  router.get(
    {
      path: '/api/powerplant_logs/field_values',
      validate: false,
    },
    async (context, request, response) => {
      try {
        const searchBody = {
          size: 0,
          aggs: {
            severities: { terms: { field: 'event.severity', size: 20 } },
            device_types: { terms: { field: 'device.type', size: 50 } },
            devices: { terms: { field: 'device.id', size: 50 } },
            protocols: { terms: { field: 'protocol', size: 20 } },
            event_types: { terms: { field: 'event.type', size: 30 } },
            event_types_nested: { terms: { field: 'event.type', size: 30 } },
          },
        };

        const credentials = getCredentials();
        const result = await queryOpenSearch(`/${LOGS_INDEX}/_search`, 'POST', searchBody, credentials);

        if (result.error) {
          return response.customError({
            statusCode: result.status || 500,
            body: { message: result.error?.reason || 'OpenSearch field_values query failed' },
          });
        }

        return response.ok({ body: result });
      } catch (error) {
        console.error('Powerplant logs field_values error:', error.message || error);
        return response.customError({
          statusCode: 500,
          body: { message: error.message || 'Failed to fetch field values' },
        });
      }
    }
  );

  // ── Health check ──
  router.get(
    {
      path: '/api/powerplant_logs/status',
      validate: false,
    },
    async (context, request, response) => {
      return response.ok({
        body: { status: 'ok', message: 'Powerplant Logs plugin is running' },
      });
    }
  );
}
