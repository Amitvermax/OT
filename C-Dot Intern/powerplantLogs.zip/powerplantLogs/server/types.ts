// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface PowerplantLogsPluginSetup {}
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface PowerplantLogsPluginStart {}
