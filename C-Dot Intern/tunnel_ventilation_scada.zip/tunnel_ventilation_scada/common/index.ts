export const PLUGIN_ID = 'tunnelVentilationScada';
export const PLUGIN_NAME = 'Tunnel Ventilation SCADA';

// OpenSearch connection details
export const OPENSEARCH_HOST = 'https://172.24.32.131:9200';
export const OPENSEARCH_USERNAME = 'admin';
export const SCADA_INDEX = 'scada_smoke';
