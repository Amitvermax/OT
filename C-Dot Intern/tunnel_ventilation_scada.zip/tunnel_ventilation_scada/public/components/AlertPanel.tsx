import React, { useRef, useEffect } from 'react';
import { AlertItem } from './app';

interface AlertPanelProps {
  alerts: AlertItem[];
  onAcknowledge: (id: string) => void;
}

function alarmTypeClass(type: string): string {
  if (type.includes('SMOKE')) return 'smoke';
  if (type.includes('CO')) return 'co';
  if (type.includes('TEMPERATURE')) return 'temp';
  if (type.includes('RPM')) return 'rpm';
  return '';
}

function alarmLabel(type: string): string {
  if (type.includes('SMOKE')) return 'HIGH SMOKE';
  if (type.includes('CO')) return 'HIGH CO';
  if (type.includes('TEMPERATURE')) return 'HIGH TEMP';
  if (type.includes('RPM')) return 'HIGH RPM';
  return type;
}

export const AlertPanel: React.FC<AlertPanelProps> = ({ alerts, onAcknowledge }) => {
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = 0;
    }
  }, [alerts.length]);

  const unacknowledged = alerts.filter(a => !a.acknowledged);
  const acknowledged = alerts.filter(a => a.acknowledged);

  return (
    <div>
      <div className="scada-section-title">Live Alerts ({unacknowledged.length})</div>
      <div className="scada-panel">
        <div className="scada-alert-list" ref={listRef}>
          {alerts.length === 0 && (
            <div style={{ textAlign: 'center', color: '#4B5563', padding: '20px 0', fontSize: 11 }}>
              No alerts — system operating normally
            </div>
          )}
          {alerts.map(alert => (
            <div
              key={alert.id}
              className={`scada-alert-item ${alert.severity} ${!alert.acknowledged && alert.severity === 'critical' ? 'blink' : ''}`}
              style={{ opacity: alert.acknowledged ? 0.4 : 1 }}
            >
              <div style={{ flex: 1 }}>
                <div className="scada-alert-time">{alert.timestamp}</div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginTop: 2 }}>
                  <span className={`scada-alert-type ${alarmTypeClass(alert.alarmType)}`}>
                    {alarmLabel(alert.alarmType)}
                  </span>
                  <span style={{ color: '#6B7280', fontSize: 9 }}>{alert.tunnelId}</span>
                </div>
              </div>
              {!alert.acknowledged && (
                <button className="scada-alert-ack-btn" onClick={() => onAcknowledge(alert.id)}>
                  ACK
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
