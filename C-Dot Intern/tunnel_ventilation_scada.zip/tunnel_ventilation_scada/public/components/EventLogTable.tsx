import React, { useState, useMemo } from 'react';
import { SensorData } from './app';

interface EventLogTableProps {
  history: SensorData[];
}

const PAGE_SIZE = 20;

export const EventLogTable: React.FC<EventLogTableProps> = ({ history }) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'ALL' | 'ALERT' | 'NORMAL'>('ALL');
  const [page, setPage] = useState(0);

  const reversed = useMemo(() => [...history].reverse(), [history]);

  const filtered = useMemo(() => {
    let data = reversed;
    if (filter === 'ALERT') data = data.filter(d => d.alarmStatus !== 'NORMAL');
    if (filter === 'NORMAL') data = data.filter(d => d.alarmStatus === 'NORMAL');
    if (search.trim()) {
      const q = search.toLowerCase();
      data = data.filter(d =>
        d.timestamp.toLowerCase().includes(q) ||
        d.alarmStatus.toLowerCase().includes(q) ||
        d.temperature.toString().includes(q) ||
        d.coLevel.toString().includes(q)
      );
    }
    return data;
  }, [reversed, filter, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);
  const pageData = filtered.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE);

  const exportCsv = () => {
    const headers = 'Timestamp,Type,Temperature,Smoke,CO,FanRPM,Power,Alarm\n';
    const rows = filtered.map(d =>
      `${d.timestamp},${d.alarmStatus === 'NORMAL' ? 'NORMAL' : 'ALERT'},${d.temperature},${d.smokeDensity},${d.coLevel},${d.fanRpm},${d.powerKw},${d.alarmStatus}`
    ).join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `scada_log_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const alarmColor = (status: string) => {
    if (status.includes('SMOKE')) return '#FF9100';
    if (status.includes('CO')) return '#FF1744';
    if (status.includes('TEMPERATURE')) return '#FFD600';
    if (status.includes('RPM')) return '#00E5FF';
    return '#00FF88';
  };

  return (
    <div>
      <div className="scada-section-title">Event Log</div>
      <div className="scada-panel">
        <div className="scada-log-toolbar">
          <input
            className="scada-log-search"
            placeholder="Search logs..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(0); }}
          />
          {(['ALL', 'ALERT', 'NORMAL'] as const).map(f => (
            <button
              key={f}
              className={`scada-log-filter-btn ${filter === f ? 'active' : ''}`}
              onClick={() => { setFilter(f); setPage(0); }}
            >
              {f}
            </button>
          ))}
          <button className="scada-log-export-btn" onClick={exportCsv}>⬇ EXPORT CSV</button>
        </div>
        <div className="scada-log-table-wrap">
          <table className="scada-log-table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Type</th>
                <th>Temp (°C)</th>
                <th>Smoke</th>
                <th>CO (ppm)</th>
                <th>Fan RPM</th>
                <th>Power (kW)</th>
                <th>Alarm Status</th>
              </tr>
            </thead>
            <tbody>
              {pageData.length === 0 && (
                <tr><td colSpan={8} style={{ textAlign: 'center', color: '#4B5563', padding: 20 }}>No log entries</td></tr>
              )}
              {pageData.map((d, i) => {
                const isAlert = d.alarmStatus !== 'NORMAL';
                return (
                  <tr key={`${d.timestamp}-${i}`} className={isAlert ? 'alert-row' : 'normal-row'}>
                    <td style={{ color: '#9CA3AF' }}>{d.timestamp}</td>
                    <td>
                      <span style={{
                        color: isAlert ? '#FF1744' : '#00FF88',
                        fontWeight: 600,
                      }}>
                        {isAlert ? 'ALERT' : 'NORMAL'}
                      </span>
                    </td>
                    <td>{d.temperature.toFixed(1)}</td>
                    <td>{d.smokeDensity.toFixed(3)}</td>
                    <td>{d.coLevel.toFixed(1)}</td>
                    <td>{d.fanRpm}</td>
                    <td>{d.powerKw.toFixed(1)}</td>
                    <td style={{ color: alarmColor(d.alarmStatus) }}>{d.alarmStatus}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="scada-log-pagination">
          <span>{filtered.length} entries</span>
          <button className="scada-log-page-btn" disabled={safePage <= 0} onClick={() => setPage(p => p - 1)}>
            ◀ Prev
          </button>
          <span>Page {safePage + 1} / {totalPages}</span>
          <button className="scada-log-page-btn" disabled={safePage >= totalPages - 1} onClick={() => setPage(p => p + 1)}>
            Next ▶
          </button>
        </div>
      </div>
    </div>
  );
};
