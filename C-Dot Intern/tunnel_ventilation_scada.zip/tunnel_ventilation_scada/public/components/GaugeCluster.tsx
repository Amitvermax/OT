import React from 'react';
import { SensorData } from './app';

interface GaugeClusterProps {
  latest: SensorData | null;
}

interface GaugeConfig {
  label: string;
  value: number;
  min: number;
  max: number;
  unit: string;
  greenEnd: number;
  yellowEnd: number;
}

function Gauge({ label, value, min, max, unit, greenEnd, yellowEnd }: GaugeConfig) {
  const startAngle = -225;
  const endAngle = 45;
  const totalArc = endAngle - startAngle; // 270 degrees
  const cx = 60, cy = 55, r = 40;

  const pct = Math.min(1, Math.max(0, (value - min) / (max - min)));
  const needleAngle = startAngle + pct * totalArc;

  function arcPath(from: number, to: number, radius: number): string {
    const fromRad = (from * Math.PI) / 180;
    const toRad = (to * Math.PI) / 180;
    const x1 = cx + radius * Math.cos(fromRad);
    const y1 = cy + radius * Math.sin(fromRad);
    const x2 = cx + radius * Math.cos(toRad);
    const y2 = cy + radius * Math.sin(toRad);
    const largeArc = to - from > 180 ? 1 : 0;
    return `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2}`;
  }

  const greenPct = (greenEnd - min) / (max - min);
  const yellowPct = (yellowEnd - min) / (max - min);
  const greenAngleEnd = startAngle + greenPct * totalArc;
  const yellowAngleEnd = startAngle + yellowPct * totalArc;

  const needleRad = (needleAngle * Math.PI) / 180;
  const nx = cx + (r - 8) * Math.cos(needleRad);
  const ny = cy + (r - 8) * Math.sin(needleRad);

  return (
    <div className="scada-gauge-box scada-panel">
      <svg className="scada-gauge-svg" viewBox="0 0 120 100">
        {/* Background arc */}
        <path d={arcPath(startAngle, endAngle, r)} fill="none" stroke="#1f2937" strokeWidth="6" strokeLinecap="round" />
        {/* Green arc */}
        <path d={arcPath(startAngle, greenAngleEnd, r)} fill="none" stroke="#00FF88" strokeWidth="6" strokeLinecap="round" opacity="0.7" />
        {/* Yellow arc */}
        <path d={arcPath(greenAngleEnd, yellowAngleEnd, r)} fill="none" stroke="#FF9100" strokeWidth="6" strokeLinecap="round" opacity="0.7" />
        {/* Red arc */}
        <path d={arcPath(yellowAngleEnd, endAngle, r)} fill="none" stroke="#FF1744" strokeWidth="6" strokeLinecap="round" opacity="0.7" />
        {/* Needle */}
        <line
          x1={cx} y1={cy} x2={nx} y2={ny}
          stroke="#E5E7EB" strokeWidth="2" strokeLinecap="round"
          style={{ transition: 'all 0.8s cubic-bezier(0.4, 0, 0.2, 1)' }}
        />
        <circle cx={cx} cy={cy} r="3" fill="#E5E7EB" />
        {/* Value */}
        <text x={cx} y={cy + 18} textAnchor="middle" fill="#00E5FF" fontSize="12" fontWeight="700" fontFamily="JetBrains Mono, monospace">
          {value.toFixed(value < 10 ? 1 : 0)}
        </text>
        <text x={cx} y={cy + 28} textAnchor="middle" fill="#6B7280" fontSize="7" fontFamily="JetBrains Mono, monospace">
          {unit}
        </text>
      </svg>
      <div className="scada-gauge-label">{label}</div>
    </div>
  );
}

export const GaugeCluster: React.FC<GaugeClusterProps> = ({ latest }) => {
  const gauges: GaugeConfig[] = [
    { label: 'Fan RPM', value: latest?.fanRpm ?? 0, min: 0, max: 4000, unit: 'RPM', greenEnd: 2500, yellowEnd: 3200 },
    { label: 'CO Level', value: latest?.coLevel ?? 0, min: 0, max: 200, unit: 'PPM', greenEnd: 50, yellowEnd: 100 },
    { label: 'Temperature', value: latest?.temperature ?? 0, min: 0, max: 80, unit: '°C', greenEnd: 40, yellowEnd: 60 },
    { label: 'Power', value: latest?.powerKw ?? 0, min: 0, max: 800, unit: 'kW', greenEnd: 400, yellowEnd: 600 },
  ];

  return (
    <div>
      <div className="scada-section-title">Gauge Cluster</div>
      <div className="scada-gauge-grid">
        {gauges.map(g => <Gauge key={g.label} {...g} />)}
      </div>
    </div>
  );
};
