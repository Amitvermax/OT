import React, { useState, useEffect } from 'react';

export type TimeRange = '5m' | '15m' | '30m' | '1h' | '6h' | '24h' | 'custom';

interface HeaderBarProps {
  health: 'green' | 'yellow' | 'red';
  alertCount: number;
  isLive: boolean;
  onToggleLive: () => void;
  dataSource: 'opensearch' | 'simulation' | 'loading';
  onToggleDataSource: () => void;
  timeRange: TimeRange;
  onTimeRangeChange: (range: TimeRange) => void;
  customFrom: string;
  customTo: string;
  onCustomFromChange: (val: string) => void;
  onCustomToChange: (val: string) => void;
}

const TIME_RANGES: { value: TimeRange; label: string }[] = [
  { value: '5m', label: '5 min' },
  { value: '15m', label: '15 min' },
  { value: '30m', label: '30 min' },
  { value: '1h', label: '1 hr' },
  { value: '6h', label: '6 hr' },
  { value: '24h', label: '24 hr' },
  { value: 'custom', label: 'Custom' },
];

export const HeaderBar: React.FC<HeaderBarProps> = ({
  health, alertCount, isLive, onToggleLive, dataSource, onToggleDataSource,
  timeRange, onTimeRangeChange, customFrom, customTo, onCustomFromChange, onCustomToChange,
}) => {
  const [clock, setClock] = useState('');

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const date = now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
      const time = now.toLocaleTimeString('en-IN', { hour12: false });
      setClock(`${date}  ${time}`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="scada-header" style={{ flexWrap: 'wrap', gap: 10 }}>
      <div className="scada-header-title">
        ◈ Tunnel Ventilation SCADA Control System
      </div>
      <div className="scada-header-right" style={{ flexWrap: 'wrap' }}>
        {/* Time range filter */}
        <div className="scada-time-filter">
          {TIME_RANGES.map(tr => (
            <button
              key={tr.value}
              className={`scada-time-btn ${timeRange === tr.value ? 'active' : ''}`}
              onClick={() => onTimeRangeChange(tr.value)}
            >
              {tr.label}
            </button>
          ))}
        </div>

        {/* Custom date range inputs */}
        {timeRange === 'custom' && (
          <div className="scada-custom-range">
            <label style={{ color: '#9CA3AF', fontSize: 10, marginRight: 4 }}>FROM</label>
            <input
              type="datetime-local"
              className="scada-datetime-input"
              value={customFrom}
              onChange={e => onCustomFromChange(e.target.value)}
            />
            <label style={{ color: '#9CA3AF', fontSize: 10, margin: '0 4px' }}>TO</label>
            <input
              type="datetime-local"
              className="scada-datetime-input"
              value={customTo}
              onChange={e => onCustomToChange(e.target.value)}
            />
          </div>
        )}

        <div className="scada-clock">{clock}</div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className={`scada-status-dot ${health}`} />
          <span style={{ fontSize: 11, color: '#9CA3AF', textTransform: 'uppercase' as const, letterSpacing: 1 }}>
            System {health === 'green' ? 'Normal' : health === 'yellow' ? 'Warning' : 'Critical'}
          </span>
        </div>

        {alertCount > 0 && (
          <span className="scada-badge alerts">
            ⚠ {alertCount} Active Alert{alertCount > 1 ? 's' : ''}
          </span>
        )}

        <span className="scada-badge online">
          <span className="scada-status-dot green" style={{ width: 7, height: 7, marginRight: 0 }} />
          ONLINE
        </span>

        {/* Data source toggle */}
        <button
          className="scada-toggle-btn"
          onClick={onToggleDataSource}
          style={{
            borderColor: dataSource === 'opensearch' ? '#00E5FF' : '#FFD600',
            color: dataSource === 'opensearch' ? '#00E5FF' : '#FFD600',
            background: dataSource === 'opensearch' ? 'rgba(0,229,255,0.1)' : 'rgba(255,214,0,0.1)',
          }}
        >
          {dataSource === 'opensearch' ? '◉ OPENSEARCH' : dataSource === 'simulation' ? '◎ SIMULATED' : '⟳ LOADING'}
        </button>

        <button
          className={`scada-toggle-btn ${isLive ? 'active' : ''}`}
          onClick={onToggleLive}
        >
          {isLive ? '● LIVE' : '○ PAUSED'}
        </button>
      </div>
    </div>
  );
};
