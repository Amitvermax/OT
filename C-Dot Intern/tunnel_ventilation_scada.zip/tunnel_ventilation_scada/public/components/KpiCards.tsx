import React from 'react';
import { SensorData } from './app';

interface KpiCardsProps {
  latest: SensorData | null;
  history: SensorData[];
  thresholds: any;
}

function getSeverity(value: number, warn: number, crit: number): 'normal' | 'warning' | 'critical' {
  if (value >= crit) return 'critical';
  if (value >= warn) return 'warning';
  return 'normal';
}

function buildSparklinePath(data: number[], width: number, height: number): string {
  if (data.length < 2) return '';
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const stepX = width / (data.length - 1);
  return data.map((v, i) => {
    const x = i * stepX;
    const y = height - ((v - min) / range) * (height - 4) - 2;
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
}

function sparklineColor(severity: string): string {
  if (severity === 'critical') return '#FF1744';
  if (severity === 'warning') return '#FF9100';
  return '#00FF88';
}

const CARDS = [
  { key: 'temperature', label: 'Avg Temperature', unit: '°C', field: 'temperature' as const, warnKey: 'temperature' },
  { key: 'smoke', label: 'Smoke Density', unit: 'idx', field: 'smokeDensity' as const, warnKey: 'smokeDensity' },
  { key: 'co', label: 'CO Level', unit: 'ppm', field: 'coLevel' as const, warnKey: 'coLevel' },
  { key: 'rpm', label: 'Fan RPM', unit: 'rpm', field: 'fanRpm' as const, warnKey: 'fanRpm' },
  { key: 'power', label: 'Power Consumption', unit: 'kW', field: 'powerKw' as const, warnKey: 'powerKw' },
  { key: 'alarms', label: 'Active Alarms', unit: '', field: null, warnKey: null },
];

export const KpiCards: React.FC<KpiCardsProps> = ({ latest, history, thresholds }) => {
  const last30 = history.slice(-30);
  const alarmCount = latest && latest.alarmStatus !== 'NORMAL' ? 1 : 0;

  return (
    <div className="scada-kpi-grid">
      {CARDS.map(card => {
        let value = 0;
        let severity: 'normal' | 'warning' | 'critical' = 'normal';
        let sparkData: number[] = [];

        if (card.field && latest) {
          value = latest[card.field];
          const th = thresholds[card.warnKey!];
          severity = getSeverity(value, th.warn, th.crit);
          sparkData = last30.map(d => d[card.field!]);
        } else if (card.key === 'alarms') {
          value = alarmCount;
          severity = alarmCount > 0 ? 'critical' : 'normal';
          sparkData = last30.map(d => d.alarmStatus !== 'NORMAL' ? 1 : 0);
        }

        const displayValue = card.field === 'smokeDensity'
          ? value.toFixed(3)
          : card.field === 'coLevel' || card.field === 'temperature' || card.field === 'powerKw'
            ? value.toFixed(1)
            : Math.round(value).toString();

        return (
          <div key={card.key} className={`scada-kpi-card ${severity}`}>
            <div className="scada-kpi-label">{card.label}</div>
            <div className="scada-kpi-value">
              {latest ? displayValue : '--'}
              <span className="scada-kpi-unit">{card.unit}</span>
            </div>
            <div className="scada-kpi-sparkline">
              <svg viewBox="0 0 120 30" preserveAspectRatio="none">
                {sparkData.length >= 2 && (
                  <path
                    d={buildSparklinePath(sparkData, 120, 30)}
                    stroke={sparklineColor(severity)}
                    strokeOpacity="0.8"
                  />
                )}
              </svg>
            </div>
          </div>
        );
      })}
    </div>
  );
};
