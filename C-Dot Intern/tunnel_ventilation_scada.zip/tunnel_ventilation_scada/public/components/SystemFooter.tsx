import React, { useState, useEffect } from 'react';

function randomFlicker(base: number, range: number): number {
  return base + (Math.random() - 0.5) * range;
}

export const SystemFooter: React.FC = () => {
  const [cpu, setCpu] = useState(23);
  const [latency, setLatency] = useState(12);
  const [rate, setRate] = useState(1.0);

  useEffect(() => {
    const id = setInterval(() => {
      setCpu(Math.round(randomFlicker(24, 10)));
      setLatency(Math.round(randomFlicker(14, 8)));
      setRate(Math.round(randomFlicker(1.0, 0.4) * 10) / 10);
    }, 2000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="scada-footer">
      <div className="scada-footer-items">
        <div className="scada-footer-item">
          CPU: <span className="val">{cpu}%</span>
        </div>
        <div className="scada-footer-item">
          NETWORK: <span className="val">{latency}ms</span>
        </div>
        <div className="scada-footer-item">
          INGESTION: <span className="val">{rate} logs/s</span>
        </div>
        <div className="scada-footer-item">
          DB: <span className="val" style={{ color: '#00FF88' }}>● CONNECTED</span>
        </div>
      </div>
      <div style={{ color: '#4B5563', fontSize: 10 }}>
        SCADA v1.0.0 — Tunnel Ventilation Monitoring
      </div>
    </div>
  );
};
