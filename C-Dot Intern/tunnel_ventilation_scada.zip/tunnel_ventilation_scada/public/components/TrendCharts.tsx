import React, { useRef, useEffect, useState } from 'react';
import { SensorData } from './app';

interface TrendChartsProps {
  history: SensorData[];
  thresholds: any;
}

const CHARTS = [
  { key: 'temperature', label: 'Temperature', field: 'temperature' as const, unit: '°C', color: '#FF9100', thKey: 'temperature', thField: 'crit' },
  { key: 'smoke', label: 'Smoke Density', field: 'smokeDensity' as const, unit: 'idx', color: '#FFD600', thKey: 'smokeDensity', thField: 'crit' },
  { key: 'co', label: 'CO Level', field: 'coLevel' as const, unit: 'ppm', color: '#FF1744', thKey: 'coLevel', thField: 'crit' },
  { key: 'power', label: 'Power Consumption', field: 'powerKw' as const, unit: 'kW', color: '#00E5FF', thKey: 'powerKw', thField: 'crit' },
];

function drawChart(
  canvas: HTMLCanvasElement,
  data: number[],
  color: string,
  thresholdVal: number,
  unit: string
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, w, h);

  if (data.length < 2) {
    ctx.fillStyle = '#4B5563';
    ctx.font = '12px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.fillText('Waiting for data...', w / 2, h / 2);
    return;
  }

  const pad = { top: 10, right: 10, bottom: 20, left: 45 };
  const cw = w - pad.left - pad.right;
  const ch = h - pad.top - pad.bottom;

  const minV = Math.min(...data, 0);
  const maxV = Math.max(...data, thresholdVal * 1.1);
  const range = maxV - minV || 1;

  const toX = (i: number) => pad.left + (i / (data.length - 1)) * cw;
  const toY = (v: number) => pad.top + ch - ((v - minV) / range) * ch;

  // Grid lines
  ctx.strokeStyle = 'rgba(75, 85, 99, 0.3)';
  ctx.lineWidth = 0.5;
  for (let i = 0; i <= 4; i++) {
    const y = pad.top + (ch / 4) * i;
    ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(w - pad.right, y); ctx.stroke();
    const val = maxV - (range / 4) * i;
    ctx.fillStyle = '#6B7280';
    ctx.font = '9px JetBrains Mono, monospace';
    ctx.textAlign = 'right';
    ctx.fillText(val.toFixed(1), pad.left - 5, y + 3);
  }

  // Threshold line (red dashed)
  const thY = toY(thresholdVal);
  ctx.strokeStyle = '#FF1744';
  ctx.lineWidth = 1;
  ctx.setLineDash([6, 4]);
  ctx.beginPath(); ctx.moveTo(pad.left, thY); ctx.lineTo(w - pad.right, thY); ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = '#FF1744';
  ctx.font = '8px JetBrains Mono, monospace';
  ctx.textAlign = 'left';
  ctx.fillText(`THRESHOLD ${thresholdVal}${unit}`, w - pad.right - 90, thY - 4);

  // Area fill
  ctx.beginPath();
  ctx.moveTo(toX(0), toY(data[0]));
  for (let i = 1; i < data.length; i++) ctx.lineTo(toX(i), toY(data[i]));
  ctx.lineTo(toX(data.length - 1), pad.top + ch);
  ctx.lineTo(toX(0), pad.top + ch);
  ctx.closePath();
  const grad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ch);
  grad.addColorStop(0, color + '30');
  grad.addColorStop(1, color + '05');
  ctx.fillStyle = grad;
  ctx.fill();

  // Line
  ctx.beginPath();
  ctx.moveTo(toX(0), toY(data[0]));
  for (let i = 1; i < data.length; i++) ctx.lineTo(toX(i), toY(data[i]));
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.lineJoin = 'round';
  ctx.stroke();

  // Latest value dot
  const lastI = data.length - 1;
  ctx.beginPath();
  ctx.arc(toX(lastI), toY(data[lastI]), 3, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.beginPath();
  ctx.arc(toX(lastI), toY(data[lastI]), 6, 0, Math.PI * 2);
  ctx.strokeStyle = color + '60';
  ctx.lineWidth = 1;
  ctx.stroke();
}

export const TrendCharts: React.FC<TrendChartsProps> = ({ history, thresholds }) => {
  const canvasRefs = useRef<(HTMLCanvasElement | null)[]>([null, null, null, null]);
  const [tooltip, setTooltip] = useState<{ x: number; y: number; text: string; chartIdx: number } | null>(null);

  useEffect(() => {
    const last180 = history.slice(-180);
    CHARTS.forEach((chart, idx) => {
      const canvas = canvasRefs.current[idx];
      if (!canvas) return;
      const data = last180.map(d => d[chart.field]);
      drawChart(canvas, data, chart.color, thresholds[chart.thKey][chart.thField], chart.unit);
    });
  }, [history, thresholds]);

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>, chartIdx: number) => {
    const canvas = canvasRefs.current[chartIdx];
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const pad = 45;
    const cw = rect.width - pad - 10;
    const last180 = history.slice(-180);
    if (last180.length < 2) return;
    const idx = Math.round(((x - pad) / cw) * (last180.length - 1));
    if (idx < 0 || idx >= last180.length) { setTooltip(null); return; }
    const dp = last180[idx];
    const chart = CHARTS[chartIdx];
    setTooltip({
      x: e.clientX - rect.left + 10,
      y: e.clientY - rect.top - 30,
      text: `${dp.timestamp}  |  ${dp[chart.field].toFixed(1)} ${chart.unit}`,
      chartIdx,
    });
  };

  return (
    <div>
      <div className="scada-section-title">Real-Time Trends</div>
      <div className="scada-charts-grid">
        {CHARTS.map((chart, idx) => (
          <div key={chart.key} className="scada-panel scada-chart-box" style={{ position: 'relative' }}>
            <div className="scada-chart-title">
              <span className="dot" style={{ background: chart.color }} />
              {chart.label}
            </div>
            <canvas
              ref={el => { canvasRefs.current[idx] = el; }}
              className="scada-chart-canvas"
              onMouseMove={e => handleMouseMove(e, idx)}
              onMouseLeave={() => setTooltip(null)}
            />
            {tooltip && tooltip.chartIdx === idx && (
              <div className="scada-chart-tooltip" style={{ left: tooltip.x, top: tooltip.y }}>
                {tooltip.text}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
