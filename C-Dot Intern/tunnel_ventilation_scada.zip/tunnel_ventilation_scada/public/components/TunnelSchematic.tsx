import React from 'react';
import { SensorData } from './app';

interface TunnelSchematicProps {
  latest: SensorData | null;
}

function zoneColor(temp: number): string {
  if (temp >= 60) return '#FF1744';
  if (temp >= 45) return '#FF9100';
  return '#00FF88';
}

export const TunnelSchematic: React.FC<TunnelSchematicProps> = ({ latest }) => {
  const temp = latest?.temperature ?? 30;
  const rpm = latest?.fanRpm ?? 2000;
  const airflow = latest?.airflow ?? 5;
  const fanSpeed = Math.max(0.3, rpm / 4000) * 2;

  const zones = [
    { x: 80, label: 'Zone A', temp: temp - 2 + Math.random() * 2 },
    { x: 340, label: 'Zone B', temp },
    { x: 600, label: 'Zone C', temp: temp + 1 - Math.random() * 2 },
  ];

  return (
    <div>
      <div className="scada-section-title">Tunnel Schematic — Ventilation Layout</div>
      <div className="scada-panel">
        <svg className="scada-tunnel-svg" viewBox="0 0 800 220" preserveAspectRatio="xMidYMid meet">
          <defs>
            <linearGradient id="tunnelGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#1a2332" />
              <stop offset="100%" stopColor="#0d1117" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
          </defs>

          {/* Tunnel bore */}
          <rect x="30" y="40" width="740" height="140" rx="70" fill="url(#tunnelGrad)" stroke="#374151" strokeWidth="2" />
          <rect x="50" y="55" width="700" height="110" rx="55" fill="none" stroke="#1f2937" strokeWidth="1" strokeDasharray="4 4" />

          {/* Zones */}
          {zones.map((z, i) => {
            const c = zoneColor(z.temp);
            return (
              <g key={i}>
                <rect x={z.x} y="60" width="160" height="100" rx="10" fill={c} fillOpacity="0.06" stroke={c} strokeOpacity="0.3" strokeWidth="1" />
                <text x={z.x + 80} y="80" textAnchor="middle" fill={c} fontSize="10" fontFamily="JetBrains Mono, monospace" fontWeight="600">
                  {z.label}
                </text>
                <text x={z.x + 80} y="95" textAnchor="middle" fill={c} fontSize="9" fontFamily="JetBrains Mono, monospace" opacity="0.8">
                  {z.temp.toFixed(1)}°C
                </text>
              </g>
            );
          })}

          {/* Fans */}
          {[160, 420, 680].map((fx, i) => (
            <g key={`fan-${i}`} transform={`translate(${fx}, 130)`}>
              <circle r="18" fill="none" stroke="#00E5FF" strokeWidth="1.5" strokeOpacity="0.4" />
              <g style={{ transformOrigin: '0 0', animation: `fan-rotate ${fanSpeed}s linear infinite` }}>
                <line x1="0" y1="-14" x2="0" y2="14" stroke="#00E5FF" strokeWidth="2" strokeLinecap="round" />
                <line x1="-12" y1="-7" x2="12" y2="7" stroke="#00E5FF" strokeWidth="2" strokeLinecap="round" />
                <line x1="-12" y1="7" x2="12" y2="-7" stroke="#00E5FF" strokeWidth="2" strokeLinecap="round" />
              </g>
              <circle r="3" fill="#00E5FF" />
              <text x="0" y="30" textAnchor="middle" fill="#9CA3AF" fontSize="8" fontFamily="JetBrains Mono, monospace">
                FAN-{i + 1}
              </text>
              <text x="0" y="40" textAnchor="middle" fill="#00E5FF" fontSize="8" fontFamily="JetBrains Mono, monospace">
                {Math.round(rpm + (Math.random() - 0.5) * 100)} RPM
              </text>
            </g>
          ))}

          {/* Airflow arrows */}
          {[100, 250, 400, 550, 700].map((ax, i) => (
            <g key={`arrow-${i}`} style={{ animation: `flow-arrow 2s linear infinite`, animationDelay: `${i * 0.3}s` }}>
              <polygon points={`${ax},110 ${ax + 15},115 ${ax},120`} fill="#00E5FF" fillOpacity="0.5" />
            </g>
          ))}

          {/* Airflow label */}
          <text x="400" y="195" textAnchor="middle" fill="#6B7280" fontSize="9" fontFamily="JetBrains Mono, monospace">
            AIRFLOW ▶ {airflow.toFixed(1)} m/s
          </text>

          {/* Legend */}
          <g transform="translate(50, 210)">
            <circle cx="0" cy="0" r="4" fill="#00FF88" /><text x="8" y="3" fill="#9CA3AF" fontSize="8" fontFamily="JetBrains Mono, monospace">Safe</text>
            <circle cx="55" cy="0" r="4" fill="#FF9100" /><text x="63" y="3" fill="#9CA3AF" fontSize="8" fontFamily="JetBrains Mono, monospace">Warning</text>
            <circle cx="130" cy="0" r="4" fill="#FF1744" /><text x="138" y="3" fill="#9CA3AF" fontSize="8" fontFamily="JetBrains Mono, monospace">Critical</text>
          </g>
        </svg>
      </div>
    </div>
  );
};
