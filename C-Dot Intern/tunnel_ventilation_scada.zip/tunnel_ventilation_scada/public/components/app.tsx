import React, { useState, useEffect, useCallback, useRef } from 'react';
import { HeaderBar, TimeRange } from './HeaderBar';
import { KpiCards } from './KpiCards';
import { TrendCharts } from './TrendCharts';
import { TunnelSchematic } from './TunnelSchematic';
import { GaugeCluster } from './GaugeCluster';
import { AlertPanel } from './AlertPanel';
import { EventLogTable } from './EventLogTable';
import { SystemFooter } from './SystemFooter';

// ===== TYPES =====
export interface SensorData {
  timestamp: string;
  temperature: number;
  smokeDensity: number;
  coLevel: number;
  airflow: number;
  oxygenPct: number;
  fanRpm: number;
  powerKw: number;
  alarmStatus: string;
  emergencyMode: boolean;
  tunnelId?: string;
  fanStatus?: string;
  logType?: string;
}

export interface AlertItem {
  id: string;
  timestamp: string;
  tunnelId: string;
  alarmType: string;
  severity: 'warning' | 'critical';
  acknowledged: boolean;
}

// ===== THRESHOLDS =====
const THRESHOLDS = {
  temperature: { warn: 45, crit: 60 },
  smokeDensity: { warn: 0.3, crit: 0.6 },
  coLevel: { warn: 50, crit: 100 },
  fanRpm: { warn: 3000, crit: 3500 },
  powerKw: { warn: 500, crit: 700 },
};

// ===== MAP OPENSEARCH DOCUMENT → SensorData =====
function mapToSensorData(source: any): SensorData {
  return {
    timestamp: source.timestamp || '',
    temperature: source.temperature_c ?? 0,
    smokeDensity: source.smoke_density ?? 0,
    coLevel: source.co_level_ppm ?? 0,
    airflow: source.airflow_m_s ?? 0,
    oxygenPct: source.oxygen_percent ?? 0,
    fanRpm: source.fan_speed_rpm ?? 0,
    powerKw: source.power_consumption_kw ?? 0,
    alarmStatus: source.alarm || 'NORMAL',
    emergencyMode: source.emergency_mode ?? false,
    tunnelId: source.tunnel_id || 'TUNNEL-A1',
    fanStatus: source.fan_status || 'RUNNING',
    logType: source.log_type || 'NORMAL',
  };
}

// ===== TIME RANGE → ISO TIMESTAMP =====
function timeRangeToISO(range: TimeRange, customFrom: string, customTo: string): { gte: string; lte?: string } {
  if (range === 'custom') {
    return {
      gte: customFrom ? new Date(customFrom).toISOString() : new Date(Date.now() - 30 * 60000).toISOString(),
      lte: customTo ? new Date(customTo).toISOString() : new Date().toISOString(),
    };
  }
  const mins: Record<string, number> = { '5m': 5, '15m': 15, '30m': 30, '1h': 60, '6h': 360, '24h': 1440 };
  const ms = (mins[range] || 30) * 60000;
  return { gte: new Date(Date.now() - ms).toISOString() };
}

// ===== SIMULATION =====
function randomWalk(current: number, min: number, max: number, step: number, mean: number): number {
  const drift = (mean - current) * 0.02;
  const noise = (Math.random() - 0.5) * step;
  return Math.max(min, Math.min(max, current + drift + noise));
}

const TUNNEL_IDS = ['TUN-A1', 'TUN-A2', 'TUN-B1'];

// ===== MAIN COMPONENT =====
export const ScadaDashboard: React.FC<{ http: any; notifications: any }> = ({ http }) => {
  const [history, setHistory] = useState<SensorData[]>([]);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [isLive, setIsLive] = useState(true);
  const [dataSource, setDataSource] = useState<'opensearch' | 'simulation' | 'loading'>('loading');
  const [forceSimulation, setForceSimulation] = useState(false);
  const [timeRange, setTimeRange] = useState<TimeRange>('30m');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');
  const lastTimestampRef = useRef<string | null>(null);
  const simRef = useRef<SensorData | null>(null);

  // ── Toggle data source manually ──
  const handleToggleDataSource = () => {
    const goToSim = !forceSimulation;
    setForceSimulation(goToSim);
    setDataSource(goToSim ? 'simulation' : 'loading');
    setHistory([]);
    setAlerts([]);
    lastTimestampRef.current = null;
    simRef.current = null;
  };

  // ── Fetch from OpenSearch with time range ──
  const fetchFromOpenSearch = useCallback(async (isInitial: boolean, range: TimeRange, cFrom: string, cTo: string) => {
    try {
      const timeFilter = timeRangeToISO(range, cFrom, cTo);
      const body: any = {
        size: isInitial ? 300 : 50,
        time_gte: timeFilter.gte,
        time_lte: timeFilter.lte || undefined,
      };
      if (!isInitial && lastTimestampRef.current) {
        body.from_timestamp = lastTimestampRef.current;
      }

      const result = await http.post('/api/tunnel_ventilation_scada/data', {
        body: JSON.stringify(body),
      });

      const hits = result?.hits?.hits || [];

      if (isInitial && hits.length === 0) {
        setDataSource('simulation');
        return [];
      }

      setDataSource('opensearch');

      const newData: SensorData[] = hits
        .map((hit: any) => mapToSensorData(hit._source))
        .reverse();

      if (newData.length > 0) {
        lastTimestampRef.current = newData[newData.length - 1].timestamp;
      }

      return newData;
    } catch (err) {
      console.error('OpenSearch fetch failed, falling back to simulation:', err);
      if (isInitial) setDataSource('simulation');
      return [];
    }
  }, [http]);

  // ── Generate simulated data ──
  const generateSimulated = useCallback((): SensorData => {
    const prev = simRef.current;
    const now = new Date();
    const temp = prev ? randomWalk(prev.temperature, 18, 75, 3, 35) : 32 + Math.random() * 5;
    const smoke = prev ? randomWalk(prev.smokeDensity, 0, 0.9, 0.05, 0.15) : 0.1 + Math.random() * 0.1;
    const co = prev ? randomWalk(prev.coLevel, 0, 180, 8, 25) : 20 + Math.random() * 10;
    const airflow = prev ? randomWalk(prev.airflow, 0.5, 12, 0.5, 5) : 4.5 + Math.random();
    const o2 = prev ? randomWalk(prev.oxygenPct, 18, 21, 0.2, 20.5) : 20.5 + Math.random() * 0.3;
    const rpm = prev ? randomWalk(prev.fanRpm, 800, 3800, 100, 2200) : 2100 + Math.random() * 200;
    const power = prev ? randomWalk(prev.powerKw, 50, 780, 30, 320) : 300 + Math.random() * 50;

    let alarm = 'NORMAL';
    if (smoke >= THRESHOLDS.smokeDensity.crit) alarm = 'HIGH_SMOKE_ALERT';
    else if (co >= THRESHOLDS.coLevel.crit) alarm = 'HIGH_CO_ALERT';
    else if (temp >= THRESHOLDS.temperature.crit) alarm = 'HIGH_TEMPERATURE_ALERT';
    else if (rpm >= THRESHOLDS.fanRpm.crit) alarm = 'HIGH_RPM_ALERT';

    const emergency = alarm !== 'NORMAL' && (smoke >= THRESHOLDS.smokeDensity.crit || co >= THRESHOLDS.coLevel.crit);

    const dp: SensorData = {
      timestamp: now.toISOString(),
      temperature: Math.round(temp * 10) / 10,
      smokeDensity: Math.round(smoke * 1000) / 1000,
      coLevel: Math.round(co * 10) / 10,
      airflow: Math.round(airflow * 10) / 10,
      oxygenPct: Math.round(o2 * 10) / 10,
      fanRpm: Math.round(rpm),
      powerKw: Math.round(power * 10) / 10,
      alarmStatus: alarm,
      emergencyMode: emergency,
      tunnelId: TUNNEL_IDS[Math.floor(Math.random() * TUNNEL_IDS.length)],
    };
    simRef.current = dp;
    return dp;
  }, []);

  // ── Process alerts ──
  const processAlerts = useCallback((dataPoints: SensorData[]) => {
    const newAlerts: AlertItem[] = [];
    for (const dp of dataPoints) {
      if (dp.alarmStatus !== 'NORMAL') {
        newAlerts.push({
          id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          timestamp: dp.timestamp,
          tunnelId: dp.tunnelId || TUNNEL_IDS[Math.floor(Math.random() * TUNNEL_IDS.length)],
          alarmType: dp.alarmStatus,
          severity: dp.emergencyMode ? 'critical' : 'warning',
          acknowledged: false,
        });
      }
    }
    if (newAlerts.length > 0) {
      setAlerts(prev => {
        const combined = [...newAlerts, ...prev];
        return combined.length > 50 ? combined.slice(0, 50) : combined;
      });
    }
  }, []);

  // ── Re-fetch when time range changes ──
  useEffect(() => {
    if (forceSimulation) return;
    lastTimestampRef.current = null;
    setHistory([]);
    fetchFromOpenSearch(true, timeRange, customFrom, customTo).then(data => {
      if (data.length > 0) {
        setHistory(data.slice(-300));
        processAlerts(data);
      }
    });
  }, [timeRange, customFrom, customTo, forceSimulation]);

  // ── Main data loop ──
  useEffect(() => {
    if (!isLive) return;
    let cancelled = false;

    // Initial load
    if (forceSimulation) {
      setDataSource('simulation');
    } else {
      fetchFromOpenSearch(true, timeRange, customFrom, customTo).then(initialData => {
        if (cancelled) return;
        if (initialData.length > 0) {
          setHistory(initialData.slice(-300));
          processAlerts(initialData);
        }
      });
    }

    const interval = setInterval(async () => {
      if (cancelled) return;

      if (!forceSimulation && dataSource === 'opensearch') {
        const newData = await fetchFromOpenSearch(false, timeRange, customFrom, customTo);
        if (newData.length > 0) {
          setHistory(prev => {
            const combined = [...prev, ...newData];
            return combined.slice(-300);
          });
          processAlerts(newData);
        }
      } else {
        const dp = generateSimulated();
        setHistory(prev => {
          const next = [...prev, dp];
          return next.length > 300 ? next.slice(-300) : next;
        });
        processAlerts([dp]);
      }
    }, 2000);

    return () => { cancelled = true; clearInterval(interval); };
  }, [isLive, dataSource, forceSimulation, fetchFromOpenSearch, generateSimulated, processAlerts, timeRange, customFrom, customTo]);

  const latest = history.length > 0 ? history[history.length - 1] : null;
  const activeAlertCount = alerts.filter(a => !a.acknowledged).length;

  const handleAcknowledge = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, acknowledged: true } : a));
  };

  const getSystemHealth = (): 'green' | 'yellow' | 'red' => {
    if (!latest) return 'green';
    if (latest.emergencyMode) return 'red';
    if (latest.alarmStatus !== 'NORMAL') return 'yellow';
    return 'green';
  };

  return (
    <div className="scada-root">
      <HeaderBar
        health={getSystemHealth()}
        alertCount={activeAlertCount}
        isLive={isLive}
        onToggleLive={() => setIsLive(p => !p)}
        dataSource={dataSource}
        onToggleDataSource={handleToggleDataSource}
        timeRange={timeRange}
        onTimeRangeChange={setTimeRange}
        customFrom={customFrom}
        customTo={customTo}
        onCustomFromChange={setCustomFrom}
        onCustomToChange={setCustomTo}
      />
      <div className="scada-main">
        <div className="scada-kpi-row">
          <KpiCards latest={latest} history={history} thresholds={THRESHOLDS} />
        </div>
        <div className="scada-charts-section">
          <TrendCharts history={history} thresholds={THRESHOLDS} />
        </div>
        <div className="scada-right-panel">
          <GaugeCluster latest={latest} />
          <AlertPanel alerts={alerts} onAcknowledge={handleAcknowledge} />
        </div>
        <div className="scada-tunnel-section">
          <TunnelSchematic latest={latest} />
        </div>
        <div className="scada-log-section">
          <EventLogTable history={history} />
        </div>
        <div className="scada-footer-section">
          <SystemFooter />
        </div>
      </div>
    </div>
  );
};
