import './index.scss';

import { TunnelVentilationScadaPlugin } from './plugin';

export function plugin() {
  return new TunnelVentilationScadaPlugin();
}
export { TunnelVentilationScadaPluginSetup, TunnelVentilationScadaPluginStart } from './types';
