import { i18n } from '@osd/i18n';
import { AppMountParameters, CoreSetup, CoreStart, Plugin } from '../../../../src/core/public';
import {
  TunnelVentilationScadaPluginSetup,
  TunnelVentilationScadaPluginStart,
  AppPluginStartDependencies,
} from './types';
import { PLUGIN_NAME } from '../common';

export class TunnelVentilationScadaPlugin
  implements Plugin<TunnelVentilationScadaPluginSetup, TunnelVentilationScadaPluginStart> {
  public setup(core: CoreSetup): TunnelVentilationScadaPluginSetup {
    core.application.register({
      id: 'tunnelVentilationScada',
      title: PLUGIN_NAME,
      order: 8,
      category: {
        id: 'trinetra',
        label: 'त्रिनेत्र',
        order: 0,
      },
      async mount(params: AppMountParameters) {
        const { renderApp } = await import('./application');
        const [coreStart, depsStart] = await core.getStartServices();
        return renderApp(coreStart, depsStart as AppPluginStartDependencies, params);
      },
    });

    return {
      getGreeting() {
        return i18n.translate('tunnelVentilationScada.greetingText', {
          defaultMessage: 'Hello from {name}!',
          values: {
            name: PLUGIN_NAME,
          },
        });
      },
    };
  }

  public start(core: CoreStart): TunnelVentilationScadaPluginStart {
    return {};
  }

  public stop() {}
}
