import { NavigationPublicPluginStart } from '../../../../src/plugins/navigation/public';

export interface TunnelVentilationScadaPluginSetup {
  getGreeting: () => string;
}
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface TunnelVentilationScadaPluginStart {}

export interface AppPluginStartDependencies {
  navigation: NavigationPublicPluginStart;
}
