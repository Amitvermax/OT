import { PluginInitializerContext } from '../../../src/core/server';
import { TunnelVentilationScadaPlugin } from './plugin';

export function plugin(initializerContext: PluginInitializerContext) {
  return new TunnelVentilationScadaPlugin(initializerContext);
}

export { TunnelVentilationScadaPluginSetup, TunnelVentilationScadaPluginStart } from './types';
