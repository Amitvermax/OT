import {
  PluginInitializerContext,
  CoreSetup,
  CoreStart,
  Plugin,
  Logger,
} from '../../../src/core/server';

import { TunnelVentilationScadaPluginSetup, TunnelVentilationScadaPluginStart } from './types';
import { defineRoutes } from './routes';

export class TunnelVentilationScadaPlugin
  implements Plugin<TunnelVentilationScadaPluginSetup, TunnelVentilationScadaPluginStart> {
  private readonly logger: Logger;

  constructor(initializerContext: PluginInitializerContext) {
    this.logger = initializerContext.logger.get();
  }

  public setup(core: CoreSetup) {
    this.logger.debug('tunnelVentilationScada: Setup');
    const router = core.http.createRouter();
    defineRoutes(router);
    return {};
  }

  public start(core: CoreStart) {
    this.logger.debug('tunnelVentilationScada: Started');
    return {};
  }

  public stop() {}
}
