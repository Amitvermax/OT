import { schema } from '@osd/config-schema';
import https from 'https';
import { OPENSEARCH_HOST, OPENSEARCH_USERNAME, SCADA_INDEX } from '../../common';

// Equivalent of Python's verify=False — skip TLS verification for self-signed certs
const agent = new https.Agent({ rejectUnauthorized: false });

function queryOpenSearch(path: string, body: any, credentials: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const url = new URL(path, OPENSEARCH_HOST);
    const postData = JSON.stringify(body);

    const req = https.request(
      {
        hostname: url.hostname,
        port: url.port || 9200,
        path: url.pathname,
        method: 'POST',
        agent,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${credentials}`,
          'Content-Length': Buffer.byteLength(postData),
        },
      },
      (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(new Error(`Failed to parse OpenSearch response: ${data.substring(0, 200)}`));
          }
        });
      }
    );

    req.on('error', (err) => reject(err));
    req.write(postData);
    req.end();
  });
}

export function defineRoutes(router) {
  // ── Fetch latest SCADA telemetry from OpenSearch ──
  router.post(
    {
      path: '/api/tunnel_ventilation_scada/data',
      validate: {
        body: schema.object({
          size: schema.number({ defaultValue: 300 }),
          from_timestamp: schema.maybe(schema.string()),
          time_gte: schema.maybe(schema.string()),
          time_lte: schema.maybe(schema.string()),
        }),
      },
    },
    async (context, request, response) => {
      try {
        const { size, from_timestamp, time_gte, time_lte } = request.body;

        // Build query with time range filter
        const filters: any[] = [];

        if (time_gte || time_lte) {
          const rangeFilter: any = {};
          if (time_gte) rangeFilter.gte = time_gte;
          if (time_lte) rangeFilter.lte = time_lte;
          filters.push({ range: { timestamp: rangeFilter } });
        }

        if (from_timestamp) {
          filters.push({ range: { timestamp: { gt: from_timestamp } } });
        }

        const query = filters.length > 0
          ? { bool: { must: filters } }
          : { match_all: {} };

        const searchBody = {
          query,
          sort: [{ timestamp: { order: 'desc' } }],
          size,
        };

        const password = process.env.OPENSEARCH_PASSWORD || 'cdot@siem@123';
        const credentials = Buffer.from(`${OPENSEARCH_USERNAME}:${password}`).toString('base64');

        const result = await queryOpenSearch(`/${SCADA_INDEX}/_search`, searchBody, credentials);

        if (result.error) {
          console.error('OpenSearch query error:', JSON.stringify(result.error));
          return response.customError({
            statusCode: result.status || 500,
            body: { message: result.error?.reason || 'OpenSearch query failed' },
          });
        }

        return response.ok({ body: result });
      } catch (error) {
        console.error('SCADA data fetch error:', error.message || error);
        return response.customError({
          statusCode: 500,
          body: { message: error.message || 'Failed to query OpenSearch for SCADA data' },
        });
      }
    }
  );

  // ── Health check ──
  router.get(
    {
      path: '/api/tunnel_ventilation_scada/status',
      validate: false,
    },
    async (context, request, response) => {
      return response.ok({
        body: { status: 'ok', message: 'Tunnel Ventilation SCADA plugin is running' },
      });
    }
  );
}
