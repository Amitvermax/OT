// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface TunnelVentilationScadaPluginSetup {}
// eslint-disable-next-line @typescript-eslint/no-empty-interface
export interface TunnelVentilationScadaPluginStart {}
